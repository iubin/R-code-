# install.packages("fda")  
library(fda)

set.seed(2026)

# ----------------------------
# 1) 模拟 40 条“充电曲线”
# ----------------------------
n_subject <- 8
n_trial   <- 5
n         <- n_subject * n_trial

# 连续域：0~10（分钟），与示意图横轴相近
t <- seq(0, 10, length.out = 201)

sim_charge_curve <- function(t) {
  # 平台值（类似你图里的 250~320）
  A <- rnorm(1, mean = 290, sd = 18)
  
  # 上升速度（越大上升越快）
  k <- rlnorm(1, meanlog = log(1.3), sdlog = 0.25)
  
  # 起始延迟（模拟插电/接触不良等）
  delay <- runif(1, 0, 1.2)
  
  # 基本“快速上升->平台”形态
  y <- A * (1 - exp(-k * pmax(t - delay, 0)))
  
  # 一部分曲线加入“二阶段缓慢爬升”（制造多样性，类似你图里后段还在上升的曲线）
  if (runif(1) < 0.35) {
    A2 <- rnorm(1, mean = 35, sd = 10)
    k2 <- rlnorm(1, meanlog = log(0.35), sdlog = 0.35)
    t0 <- runif(1, 2, 5)
    y  <- y + A2 * (1 - exp(-k2 * pmax(t - t0, 0)))
  }
  
  # 加测量噪声
  y + rnorm(length(t), mean = 0, sd = 4.5)
}

Y <- sapply(1:n, function(i) sim_charge_curve(t))  # 201 x 40

# 画出类似你示意图的多条曲线
matplot(t, Y, type = "l", lty = 1,
        xlab = "Time (min)", ylab = "Voltage (mV, scaled)",
        main = "Example functional data: charging curves (raw)")

# ----------------------------
# 2) 用 FDA 的基函数平滑 -> 函数型数据对象 fdobj
# ----------------------------
rangeval <- range(t)
nbasis   <- 25
basis    <- create.bspline.basis(rangeval = rangeval, nbasis = nbasis)

# 惩罚二阶导数（roughness penalty）
Lfd      <- int2Lfd(2)
lambda   <- 1e-2
fdParobj <- fdPar(basis, Lfd, lambda)

sm <- smooth.basis(argvals = t, y = Y, fdParobj = fdParobj)
fdobj <- sm$fd

# 平滑后的函数曲线
plot(fdobj, xlab = "Time (min)", ylab = "Voltage (mV, scaled)",
     main = "Example functional data: charging curves")
