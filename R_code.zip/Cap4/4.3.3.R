############################################################
# 4.3.3 GPFR - Demanda eléctrica España: curvas diarias (24h)
# - Input:  spain_load_hourly800_800_clean.csv (en getwd())
# - Output: Fig_4_3_3_*.png, Tabla_4_3_3_*.csv, pred_*.csv, GCV_*.csv
############################################################

rm(list = ls())
set.seed(123)

############################
# 0) Packages
############################
req_pkg <- function(p){
  if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
  suppressPackageStartupMessages(library(p, character.only = TRUE))
}
req_pkg("dplyr")
req_pkg("tidyr")
req_pkg("ggplot2")
req_pkg("lubridate")
req_pkg("readr")
req_pkg("fda")
req_pkg("DiceKriging")

############################
# 1) Load hourly series (800 hours)
############################
DATA_FILE <- "spain_load_hourly800_800_clean.csv"
if (!file.exists(DATA_FILE)) stop("No existe el archivo: ", DATA_FILE, "  (debe estar en getwd())")

raw <- readr::read_csv(DATA_FILE, show_col_types = FALSE)

# ---- guess datetime column
guess_datetime_col <- function(df){
  cand <- names(df)
  # Priority names
  pri <- c("datetime","date_time","timestamp","time","date","Fecha","FECHA","FECHA_HORA_INI","FECHA_HORA")
  hit <- pri[pri %in% cand]
  if (length(hit) > 0) return(hit[1])
  
  # Otherwise pick first character column that can be parsed by ymd_hms/ymd hm
  for (nm in cand){
    if (is.character(df[[nm]]) || inherits(df[[nm]], "POSIXt")){
      x <- df[[nm]]
      if (inherits(x, "POSIXt")) return(nm)
      ok1 <- suppressWarnings(!all(is.na(lubridate::ymd_hms(x))))
      ok2 <- suppressWarnings(!all(is.na(lubridate::ymd_hm(x))))
      ok3 <- suppressWarnings(!all(is.na(lubridate::dmy_hms(x))))
      ok4 <- suppressWarnings(!all(is.na(lubridate::dmy_hm(x))))
      if (ok1 || ok2 || ok3 || ok4) return(nm)
    }
  }
  stop("No pude detectar columna datetime. Renombra tu columna a 'datetime'.")
}

# ---- guess load column
guess_load_col <- function(df){
  cand <- names(df)
  pri <- c("load","Load","demand","Demand","mw","MW","y","Y","value","valor")
  hit <- pri[pri %in% cand]
  if (length(hit) > 0) return(hit[1])
  
  # Otherwise pick the numeric column with largest variance
  num_cols <- cand[sapply(df, is.numeric)]
  if (length(num_cols) == 0) stop("No hay columnas numéricas para la demanda.")
  v <- sapply(num_cols, function(nm) var(df[[nm]], na.rm = TRUE))
  num_cols[which.max(v)]
}

dt_col <- guess_datetime_col(raw)
y_col  <- guess_load_col(raw)

df <- raw %>%
  dplyr::transmute(
    datetime_raw = .data[[dt_col]],
    y = as.numeric(.data[[y_col]])
  )

# parse datetime robustly
df$datetime <- df$datetime_raw
if (!inherits(df$datetime, "POSIXt")) {
  df$datetime <- suppressWarnings(lubridate::ymd_hms(df$datetime_raw, tz = "UTC"))
  if (all(is.na(df$datetime))) df$datetime <- suppressWarnings(lubridate::ymd_hm(df$datetime_raw, tz = "UTC"))
  if (all(is.na(df$datetime))) df$datetime <- suppressWarnings(lubridate::dmy_hms(df$datetime_raw, tz = "UTC"))
  if (all(is.na(df$datetime))) df$datetime <- suppressWarnings(lubridate::dmy_hm(df$datetime_raw, tz = "UTC"))
}
if (all(is.na(df$datetime))) stop("No pude parsear datetime. Revisa el formato en la columna: ", dt_col)

df <- df %>%
  dplyr::filter(!is.na(datetime), !is.na(y)) %>%
  dplyr::arrange(datetime)

df <- df %>%
  dplyr::group_by(datetime) %>%
  dplyr::slice(1) %>%
  dplyr::ungroup()

############################
# 2) Build daily curves of 24 points
############################
df_day <- df %>%
  dplyr::mutate(
    date = as.Date(datetime),
    hour = lubridate::hour(datetime) + 1   # 1..24
  ) %>%
  dplyr::select(date, hour, y) %>%
  dplyr::arrange(date, hour)

# Keep only full days (24 obs)
full_days <- df_day %>%
  dplyr::count(date, name = "n") %>%
  dplyr::filter(n == 24) %>%
  dplyr::pull(date)

df_day <- df_day %>% dplyr::filter(date %in% full_days)

# Rebuild as matrix: 24 x n_days
days <- sort(unique(df_day$date))
n_days <- length(days)
if (n_days < 10) warning("Pocos días completos (n_days=", n_days, "). Con 800 horas suele quedar ~33 días.")

Ymat <- matrix(NA_real_, nrow = 24, ncol = n_days)
for (i in seq_along(days)) {
  tmp <- df_day %>% dplyr::filter(date == days[i]) %>% dplyr::arrange(hour)
  Ymat[, i] <- tmp$y
}
hour_grid <- 1:24

############################
# 3) Train/test split by curves (days) - chronological to avoid leakage
############################
train_frac <- 0.7
n_train_days <- floor(n_days * train_frac)
train_days <- days[1:n_train_days]
test_days  <- days[(n_train_days + 1):n_days]

idx_train <- 1:n_train_days
idx_test  <- (n_train_days + 1):n_days

Y_train <- Ymat[, idx_train, drop = FALSE]
Y_test  <- Ymat[, idx_test,  drop = FALSE]

############################
# 4) Intra-curve smoothing (Fourier basis) + lambda via GCV
############################
# Fourier basis: periodic daily profile (24h). nbasis should be odd.
nbasis <- 11
basis <- fda::create.fourier.basis(rangeval = c(1,24), nbasis = nbasis)

# Grid of lambda for GCV
lambda_grid <- 10^seq(-8, 4, length.out = 25)

mean_gcv_of <- function(sb){
  g <- sb$gcv
  if (is.null(g)) return(NA_real_)
  mean(as.numeric(g), na.rm = TRUE)
}

gcv_vals <- numeric(length(lambda_grid))

for (k in seq_along(lambda_grid)) {
  fdPar_k <- fda::fdPar(fdobj = basis, Lfdobj = 2, lambda = lambda_grid[k])
  sb_k <- fda::smooth.basis(argvals = hour_grid, y = Y_train, fdParobj = fdPar_k)
  gcv_vals[k] <- mean_gcv_of(sb_k)
}

lambda_hat <- lambda_grid[which.min(gcv_vals)]

gcv_table <- data.frame(lambda = lambda_grid, gcv_mean = gcv_vals)
write.csv(gcv_table, "GCV_4_3_3_grid_GPFR_spain_load_daily24.csv", row.names = FALSE)

# Final smoothing on ALL days using selected lambda
fdPar_hat <- fda::fdPar(fdobj = basis, Lfdobj = 2, lambda = lambda_hat)
sb_all <- fda::smooth.basis(argvals = hour_grid, y = Ymat, fdParobj = fdPar_hat)
fd_all <- sb_all$fd

# Fourier coefficients: nbasis x n_days
C_all <- fd_all$coefs
C_train <- C_all[, idx_train, drop = FALSE]
C_test  <- C_all[, idx_test,  drop = FALSE]

############################
# 5) GP on coefficients across days (functional regression over curves)
############################
# Design variable for curves (day index). No extra covariates to keep baseline comparable.
x_train <- data.frame(day = seq_len(n_train_days))
x_all   <- data.frame(day = seq_len(n_days))

coef_mean_hat <- matrix(NA_real_, nrow = nbasis, ncol = n_days)
coef_var_hat  <- matrix(NA_real_, nrow = nbasis, ncol = n_days)

for (k in 1:nbasis) {
  resp <- as.numeric(C_train[k, ])
  # GP (RBF). Nugget estimated for stability.
  fit_k <- DiceKriging::km(
    design = x_train,
    response = resp,
    covtype = "gauss",
    nugget.estim = TRUE,
    control = list(trace = FALSE)
  )
  
  pred_k <- predict(fit_k, newdata = x_all, type = "UK", se.compute = TRUE)
  
  coef_mean_hat[k, ] <- as.numeric(pred_k$mean)
  coef_var_hat[k, ]  <- (as.numeric(pred_k$sd))^2
}

############################
# 6) Reconstruct curves + 95% band
############################
Phi <- fda::eval.basis(hour_grid, basis)   # 24 x nbasis

Yhat_mat <- Phi %*% coef_mean_hat          # 24 x n_days
VarY_mat <- (Phi^2) %*% coef_var_hat       # independence approximation

Ylo_mat <- Yhat_mat - 1.96 * sqrt(pmax(VarY_mat, 0))
Yhi_mat <- Yhat_mat + 1.96 * sqrt(pmax(VarY_mat, 0))

############################
# 7) Build long tables (predictions + metrics)
############################
make_long <- function(days_vec, cols_idx){
  out <- expand.grid(
    date = days_vec,
    hour = hour_grid
  )
  # map into matrices
  # column index in full matrix
  j <- match(out$date, days)
  h <- out$hour
  
  out$y    <- as.numeric(Ymat[cbind(h, j)])
  out$yhat <- as.numeric(Yhat_mat[cbind(h, j)])
  out$ylo  <- as.numeric(Ylo_mat[cbind(h, j)])
  out$yhi  <- as.numeric(Yhi_mat[cbind(h, j)])
  out$curve_id <- j
  out
}

df_train_long <- make_long(train_days, idx_train)
df_test_long  <- make_long(test_days,  idx_test)

write.csv(df_train_long, "pred_GPFR_spain_load_daily24_train.csv", row.names = FALSE)
write.csv(df_test_long,  "pred_GPFR_spain_load_daily24_test.csv",  row.names = FALSE)

metrics <- function(y, yhat){
  mse <- mean((y - yhat)^2, na.rm = TRUE)
  mae <- mean(abs(y - yhat), na.rm = TRUE)
  sst <- sum((y - mean(y, na.rm = TRUE))^2, na.rm = TRUE)
  sse <- sum((y - yhat)^2, na.rm = TRUE)
  r2  <- 1 - sse/sst
  c(MSE = mse, MAE = mae, R2 = r2)
}

m_train <- metrics(df_train_long$y, df_train_long$yhat)
m_test  <- metrics(df_test_long$y,  df_test_long$yhat)

tabla <- data.frame(
  Modelo = "GPFR (daily curves, 24h) + Fourier + GP coef",
  nbasis = nbasis,
  lambda_hat = lambda_hat,
  n_days = n_days,
  n_train_days = n_train_days,
  n_test_days = n_days - n_train_days,
  MSE_train = m_train["MSE"],
  MAE_train = m_train["MAE"],
  R2_train  = m_train["R2"],
  MSE_test  = m_test["MSE"],
  MAE_test  = m_test["MAE"],
  R2_test   = m_test["R2"]
)

write.csv(tabla, "Tabla_4_3_3_metricas_GPFR_spain_load_daily24.csv", row.names = FALSE)

############################
# 8) Plots: real vs predicted (representative test segment)
############################
# pick up to 6 test days for visualization (representative tramo)
sel_test_days <- unique(df_test_long$date)
sel_test_days <- sel_test_days[seq_len(min(length(sel_test_days), 6))]

plot_test <- df_test_long %>%
  dplyr::filter(date %in% sel_test_days) %>%
  dplyr::mutate(date = factor(date, levels = sel_test_days))

p_test <- ggplot(plot_test, aes(x = hour)) +
  geom_ribbon(aes(ymin = ylo, ymax = yhi, group = date), alpha = 0.25) +
  geom_point(aes(y = y), size = 1) +
  geom_line(aes(y = yhat, group = date), linewidth = 0.7) +
  facet_wrap(~ date, ncol = 2, scales = "free_y") +
  labs(
    title = "Prueba (GPFR) - Demanda eléctrica España: curvas intra-diarias (24h)",
    x = "Hora del día (t=1..24)",
    y = "Demanda (MW)"
  ) +
  theme_bw()

ggsave("Fig_4_3_3_GPFR_spain_load_daily24_test.png", p_test, width = 12, height = 6, dpi = 150)

# (optional) training plot with 6 first train days
sel_train_days <- unique(df_train_long$date)
sel_train_days <- sel_train_days[seq_len(min(length(sel_train_days), 6))]

plot_train <- df_train_long %>%
  dplyr::filter(date %in% sel_train_days) %>%
  dplyr::mutate(date = factor(date, levels = sel_train_days))

p_train <- ggplot(plot_train, aes(x = hour)) +
  geom_ribbon(aes(ymin = ylo, ymax = yhi, group = date), alpha = 0.25) +
  geom_point(aes(y = y), size = 1) +
  geom_line(aes(y = yhat, group = date), linewidth = 0.7) +
  facet_wrap(~ date, ncol = 2, scales = "free_y") +
  labs(
    title = "Entrenamiento (GPFR) - Demanda eléctrica España: curvas intra-diarias (24h)",
    x = "Hora del día (t=1..24)",
    y = "Demanda (MW)"
  ) +
  theme_bw()

ggsave("Fig_4_3_3_GPFR_spain_load_daily24_train.png", p_train, width = 12, height = 6, dpi = 150)

############################
# 9) Optional comparison table with existing baseline files (if present)
############################
# baseline GPR hourly (your previous chapter files)
cmp <- NULL

if (file.exists("spain_load_hourly800_metrics.csv")) {
  gpr1d <- readr::read_csv("spain_load_hourly800_metrics.csv", show_col_types = FALSE)
  # try to standardize
  # expected columns: MSE_train, MAE_train, R2_train, MSE_test, MAE_test, R2_test
  if (all(c("MSE_train","MAE_train","R2_train","MSE_test","MAE_test","R2_test") %in% names(gpr1d))) {
    cmp <- dplyr::bind_rows(cmp, dplyr::mutate(gpr1d, Modelo = "GPR 1D (RBF) - hourly800"))
  }
}

if (file.exists("Tabla_3_3_metricas_FDA_spain_load.csv")) {
  fda1 <- readr::read_csv("Tabla_3_3_metricas_FDA_spain_load.csv", show_col_types = FALSE)
  if (all(c("MSE_train","MAE_train","R2_train","MSE_test","MAE_test","R2_test") %in% names(fda1))) {
    cmp <- dplyr::bind_rows(cmp, dplyr::mutate(fda1, Modelo = "FDA - hourly800"))
  }
}

cmp <- dplyr::bind_rows(
  cmp,
  tabla %>% dplyr::select(Modelo, MSE_train, MAE_train, R2_train, MSE_test, MAE_test, R2_test)
)

if (!is.null(cmp)) {
  write.csv(cmp, "Tabla_4_3_3_comparacion_baselines.csv", row.names = FALSE)
}

cat("OK. Outputs written to: ", getwd(), "\n")
print(tabla)
