############################################################
# 4.3.2 GPFR (ejecutable) - Madrid Retiro
#   y(t) = pres_mean (hPa), covariables a nivel de curva: tmed + fecha (y opcional estacionalidad)
#
# 1) Convertir 800 puntos diarios en M curvas de longitud L
# 2) Etapa 1: base (B-spline/Fourier) + suavizado con lambda por GCV
# 3) Etapa 2: GP sobre coeficientes (uno por cada base) con entradas de curva
# 4) Predicción:
#    - Escenario B: sin observaciones (solo X_curve)
#    - Escenario A: con observaciones parciales (primer p_obs de puntos)
#
# Todas las salidas se guardan en el directorio de trabajo (getwd()).
############################################################

# -----------------------------
# 0) Paquetes (sin gridExtra)
# -----------------------------
pkgs <- c("fda", "ggplot2", "dplyr", "tidyr", "DiceKriging")
need <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(need) > 0) install.packages(need, repos = "https://cloud.r-project.org")

library(fda)
library(ggplot2)
library(dplyr)
library(tidyr)
library(DiceKriging)

set.seed(123)

# -----------------------------
# 1) Parámetros
# -----------------------------
FILE_IN <- "retiro_3195_daily_800_clean.csv"

L <- 20                  # longitud de cada curva (recomendado: 20 o 24)
K <- 11                  # nbasis
BASIS_TYPE <- "bspline"  # "bspline" o "fourier"
USE_SEASON_FEATURES <- TRUE   # incluir sin/cos del día del año
p_obs <- 0.30                 # Escenario A: % observado al inicio

# -----------------------------
# 2) Utilidades
# -----------------------------
stop_if_missing <- function(path){
  if (!file.exists(path)) {
    stop(paste0("No existe: ", path, "\n",
                "CSV disponibles en el directorio:\n",
                paste(list.files(pattern="\\.csv$", ignore.case=TRUE), collapse="\n")))
  }
}

scale_with_train <- function(x_train, x_new){
  mu <- apply(x_train, 2, mean)
  sdv <- apply(x_train, 2, sd)
  sdv[sdv == 0] <- 1
  list(
    train = sweep(sweep(x_train, 2, mu, "-"), 2, sdv, "/"),
    new   = sweep(sweep(x_new,   2, mu, "-"), 2, sdv, "/"),
    mu = mu, sd = sdv
  )
}

make_basis <- function(L, K, type = c("bspline","fourier")){
  type <- match.arg(type)
  if (type == "fourier") {
    create.fourier.basis(rangeval = c(1, L), nbasis = K, period = L)
  } else {
    create.bspline.basis(rangeval = c(1, L), nbasis = K, norder = 4)
  }
}

metrics <- function(y, yhat){
  y <- as.numeric(y); yhat <- as.numeric(yhat)
  mse <- mean((y - yhat)^2, na.rm=TRUE)
  mae <- mean(abs(y - yhat), na.rm=TRUE)
  sst <- sum((y - mean(y, na.rm=TRUE))^2, na.rm=TRUE)
  sse <- sum((y - yhat)^2, na.rm=TRUE)
  r2 <- ifelse(sst > 0, 1 - sse/sst, NA_real_)
  c(MSE=mse, MAE=mae, R2=r2)
}

# -----------------------------
# 3) Leer datos
# -----------------------------
stop_if_missing(FILE_IN)
df <- read.csv(FILE_IN, stringsAsFactors = FALSE)

# columna fecha
date_candidates <- c("fecha", "Fecha", "FECHA", "date", "Date", "datetime", "Datetime")
date_col <- date_candidates[date_candidates %in% names(df)][1]
if (is.na(date_col)) stop("No encuentro columna de fecha (fecha/FECHA/date/datetime).")
df[[date_col]] <- as.Date(df[[date_col]])
df <- df %>% arrange(.data[[date_col]])

# tmed (covariable)
tmed_candidates <- c("tmed", "tmedc", "tmed_cor", "tmedcor", "tmedcorr", "temp", "temperature")
tmed_col <- tmed_candidates[tmed_candidates %in% names(df)][1]
if (is.na(tmed_col)) stop("No encuentro columna de temperatura (tmed...).")

# pres_mean (target) o calcular con presMax/presMin
pres_mean_candidates <- c("pres_mean", "presMean", "pres_media", "pres")
presmax_candidates <- c("presMax", "pres_max", "presmax")
presmin_candidates <- c("presMin", "pres_min", "presmin")

pres_mean_col <- pres_mean_candidates[pres_mean_candidates %in% names(df)][1]
if (is.na(pres_mean_col)) {
  pmx <- presmax_candidates[presmax_candidates %in% names(df)][1]
  pmn <- presmin_candidates[presmin_candidates %in% names(df)][1]
  if (is.na(pmx) || is.na(pmn)) stop("No encuentro pres_mean ni (presMax, presMin).")
  df$pres_mean <- (df[[pmx]] + df[[pmn]])/2
  pres_mean_col <- "pres_mean"
}

# quedarse con 800
df <- df %>% slice(1:800)

# -----------------------------
# 4) Convertir a curvas (L x M)
# -----------------------------
M <- floor(nrow(df)/L)
N_used <- M * L
df <- df %>% slice(1:N_used)

y_vec <- df[[pres_mean_col]]     # respuesta
cov_vec <- df[[tmed_col]]        # covariable
dates <- df[[date_col]]

Y <- matrix(y_vec, nrow = L, ncol = M)
COV <- matrix(cov_vec, nrow = L, ncol = M)

# covariables a nivel de curva
mid_idx <- (seq_len(M)-1)*L + ceiling(L/2)
mid_date <- dates[mid_idx]
mid_date_num <- as.numeric(mid_date)
mean_tmed <- colMeans(COV, na.rm = TRUE)

X_curve <- data.frame(
  mid_date = mid_date_num,
  mean_tmed = mean_tmed
)

# estacionalidad (opcional)
if (USE_SEASON_FEATURES) {
  doy <- as.integer(format(mid_date, "%j"))
  X_curve$sin_doy <- sin(2*pi*doy/365)
  X_curve$cos_doy <- cos(2*pi*doy/365)
}

# -----------------------------
# 5) Split 7:3 a nivel de curva
# -----------------------------
n_train <- floor(0.7 * M)
train_idx <- sort(sample.int(M, n_train))
test_idx  <- setdiff(seq_len(M), train_idx)

Y_tr <- Y[, train_idx, drop=FALSE]
Y_te <- Y[, test_idx,  drop=FALSE]

X_tr_raw <- as.matrix(X_curve[train_idx, , drop=FALSE])
X_te_raw <- as.matrix(X_curve[test_idx,  , drop=FALSE])

sc <- scale_with_train(X_tr_raw, X_te_raw)
X_tr <- sc$train
X_te <- sc$new

# -----------------------------
# 6) Etapa 1: base + lambda por GCV
# -----------------------------
t_grid <- 1:L
basisobj <- make_basis(L, K, BASIS_TYPE)

lambda_grid <- 10^seq(-6, 2, length.out = 25)

avg_gcv_for_lambda <- function(lambda){
  fdParobj <- fdPar(basisobj, Lfdobj = int2Lfd(2), lambda = lambda)
  sb <- smooth.basis(t_grid, Y_tr, fdParobj)
  mean(sb$gcv, na.rm = TRUE)
}
gcv_vals <- sapply(lambda_grid, avg_gcv_for_lambda)
lambda_best <- lambda_grid[which.min(gcv_vals)]

fdPar_best <- fdPar(basisobj, Lfdobj = int2Lfd(2), lambda = lambda_best)

sb_tr <- smooth.basis(t_grid, Y_tr, fdPar_best)
sb_te <- smooth.basis(t_grid, Y_te, fdPar_best)

fd_tr <- sb_tr$fd
fd_te <- sb_te$fd

coef_tr <- fd_tr$coefs  # K x n_train
coef_te <- fd_te$coefs  # K x n_test

mu_coef <- rowMeans(coef_tr)
U_tr <- sweep(coef_tr, 1, mu_coef, "-")

# ruido aproximado (residual en train tras suavizado)
Yhat_tr_smooth <- eval.fd(t_grid, fd_tr)
sigma2_hat <- mean((Y_tr - Yhat_tr_smooth)^2, na.rm = TRUE)

# -----------------------------
# 7) Etapa 2: GP por coeficiente
# -----------------------------
fit_gp_per_k <- function(U_k, X_tr){
  km(
    design = X_tr,
    response = as.numeric(U_k),
    covtype = "gauss",
    nugget.estim = TRUE,
    control = list(trace = FALSE)
  )
}
predict_gp_per_k <- function(model, X_new){
  pr <- predict(model, newdata = X_new, type = "UK", se.compute = TRUE)
  list(mean = as.numeric(pr$mean), sd = as.numeric(pr$sd))
}

gp_models <- vector("list", K)
for (k in 1:K) gp_models[[k]] <- fit_gp_per_k(U_tr[k, ], X_tr)

# -------- Escenario B: sin observaciones --------
u_mean_te <- matrix(NA_real_, nrow = K, ncol = ncol(Y_te))
u_var_te  <- matrix(NA_real_, nrow = K, ncol = ncol(Y_te))
for (k in 1:K) {
  pr <- predict_gp_per_k(gp_models[[k]], X_te)
  u_mean_te[k, ] <- pr$mean
  u_var_te[k, ]  <- (pr$sd)^2
}
coef_prior_te <- sweep(u_mean_te, 1, mu_coef, "+")
fd_prior_te <- fd(coef_prior_te, basisobj)
Yhat_te_B <- eval.fd(t_grid, fd_prior_te)

# (train in-sample para métricas train)
u_mean_tr <- matrix(NA_real_, nrow = K, ncol = ncol(Y_tr))
for (k in 1:K) {
  pr <- predict_gp_per_k(gp_models[[k]], X_tr)
  u_mean_tr[k, ] <- pr$mean
}
coef_prior_tr <- sweep(u_mean_tr, 1, mu_coef, "+")
fd_prior_tr <- fd(coef_prior_tr, basisobj)
Yhat_tr_B <- eval.fd(t_grid, fd_prior_tr)

# -----------------------------
# 8) Escenario A: actualizar con observaciones parciales
# -----------------------------
Phi_all <- eval.basis(t_grid, basisobj)  # L x K

update_coef_with_partial_obs <- function(y_obs, idx_obs, c_prior, v_prior, sigma2){
  Phi_obs <- Phi_all[idx_obs, , drop=FALSE]
  v_prior[v_prior <= 1e-12] <- 1e-12
  A <- (t(Phi_obs) %*% Phi_obs) / sigma2 + diag(1/v_prior, K)
  b <- (t(Phi_obs) %*% y_obs) / sigma2 + c_prior / v_prior
  c_post <- solve(A, b)
  Ainv <- solve(A)
  y_var <- diag(Phi_all %*% Ainv %*% t(Phi_all)) + sigma2
  list(c_post = as.numeric(c_post), y_var = y_var)
}

n_obs <- max(2, floor(L * p_obs))
idx_obs <- 1:n_obs

Yhat_te_A <- matrix(NA_real_, nrow = L, ncol = ncol(Y_te))
Ysd_te_A  <- matrix(NA_real_, nrow = L, ncol = ncol(Y_te))

for (j in 1:ncol(Y_te)) {
  y_obs <- Y_te[idx_obs, j]
  c_prior <- coef_prior_te[, j]
  v_prior <- u_var_te[, j]
  up <- update_coef_with_partial_obs(y_obs, idx_obs, c_prior, v_prior, sigma2_hat)
  
  fd_post <- fd(matrix(up$c_post, nrow=K, ncol=1), basisobj)
  Yhat_te_A[, j] <- eval.fd(t_grid, fd_post)
  Ysd_te_A[, j]  <- sqrt(pmax(up$y_var, 0))
}

# -----------------------------
# 9) Métricas y guardar CSV
# -----------------------------
met_tr_B <- metrics(Y_tr, Yhat_tr_B)
met_te_B <- metrics(Y_te, Yhat_te_B)
met_te_A <- metrics(Y_te, Yhat_te_A)

tabla <- data.frame(
  Modelo = c("GPFR-EscenarioB", "GPFR-EscenarioA"),
  MSE_train = c(met_tr_B["MSE"], NA),
  MAE_train = c(met_tr_B["MAE"], NA),
  R2_train  = c(met_tr_B["R2"],  NA),
  MSE_test  = c(met_te_B["MSE"], met_te_A["MSE"]),
  MAE_test  = c(met_te_B["MAE"], met_te_A["MAE"]),
  R2_test   = c(met_te_B["R2"],  met_te_A["R2"])
)

write.csv(tabla, "Tabla_4_3_2_metricas_GPFR_pres_mean.csv", row.names = FALSE)
write.csv(data.frame(lambda=lambda_grid, gcv=gcv_vals),
          "GCV_4_3_2_grid_GPFR_pres_mean.csv", row.names = FALSE)

pred_te_B <- data.frame(
  curve_id = rep(seq_len(ncol(Y_te)), each=L),
  t = rep(t_grid, times=ncol(Y_te)),
  y = as.vector(Y_te),
  yhat = as.vector(Yhat_te_B)
)
write.csv(pred_te_B, "pred_GPFR_pres_mean_test_EscenarioB.csv", row.names = FALSE)

pred_te_A <- data.frame(
  curve_id = rep(seq_len(ncol(Y_te)), each=L),
  t = rep(t_grid, times=ncol(Y_te)),
  y = as.vector(Y_te),
  yhat = as.vector(Yhat_te_A),
  ylo = as.vector(Yhat_te_A - 1.96*Ysd_te_A),
  yhi = as.vector(Yhat_te_A + 1.96*Ysd_te_A)
)
write.csv(pred_te_A, "pred_GPFR_pres_mean_test_EscenarioA.csv", row.names = FALSE)

# -----------------------------
# 10) Figuras (UNA curva representativa)
#     (Fix geom_ribbon: ylo/yhi siempre existen antes de usar ribbon)
# -----------------------------
pick_one_curve <- function(Ytrue, Yhat, Ysd = NULL, title){
  j <- sample.int(ncol(Ytrue), 1)
  
  dfp <- data.frame(
    t    = t_grid,
    y    = as.numeric(Ytrue[, j]),
    yhat = as.numeric(Yhat[, j])
  )
  
  if (!is.null(Ysd)) {
    dfp$ylo <- as.numeric(Yhat[, j] - 1.96 * Ysd[, j])
    dfp$yhi <- as.numeric(Yhat[, j] + 1.96 * Ysd[, j])
  }
  
  g <- ggplot(dfp, aes(x = t)) +
    theme_bw() +
    labs(title = title, x = "t (índice dentro de la curva)", y = "pres_mean (hPa)")
  
  if (!is.null(Ysd)) {
    g <- g + geom_ribbon(aes(ymin = ylo, ymax = yhi), alpha = 0.25)
  }
  
  g <- g +
    geom_point(aes(y = y), size = 1.6) +
    geom_line(aes(y = yhat), linewidth = 0.9)
  
  g
}


g_train <- pick_one_curve(Y_tr, Yhat_tr_B,
                          title = "Entrenamiento (GPFR) - pres_mean - Escenario B")
g_testB <- pick_one_curve(Y_te, Yhat_te_B,
                          title = "Prueba (GPFR) - pres_mean - Escenario B")
g_testA <- pick_one_curve(Y_te, Yhat_te_A, Ysd_te_A,
                          title = "Prueba (GPFR) - pres_mean - Escenario A (banda 95%)")

ggsave("Fig_4_3_2a_GPFR_pres_mean_train_EscB.png", g_train, width=10, height=5, dpi=150)
ggsave("Fig_4_3_2b_GPFR_pres_mean_test_EscB.png",  g_testB, width=10, height=5, dpi=150)
ggsave("Fig_4_3_2c_GPFR_pres_mean_test_EscA.png",  g_testA, width=10, height=5, dpi=150)

# -----------------------------
# 11) Mensajes finales
# -----------------------------
cat("OK\n")
cat("Directorio:", getwd(), "\n")
cat("L =", L, " K =", K, " BASIS_TYPE =", BASIS_TYPE, " USE_SEASON_FEATURES =", USE_SEASON_FEATURES, "\n")
cat("lambda_best =", lambda_best, "\n")
print(tabla)
cat("Archivos generados:\n",
    " - Tabla_4_3_2_metricas_GPFR_pres_mean.csv\n",
    " - GCV_4_3_2_grid_GPFR_pres_mean.csv\n",
    " - pred_GPFR_pres_mean_test_EscenarioB.csv\n",
    " - pred_GPFR_pres_mean_test_EscenarioA.csv\n",
    " - Fig_4_3_2a_GPFR_pres_mean_train_EscB.png\n",
    " - Fig_4_3_2b_GPFR_pres_mean_test_EscB.png\n",
    " - Fig_4_3_2c_GPFR_pres_mean_test_EscA.png\n")
