############################################################
# 4.3.1 GPFR (ejecutable) - Madrid Retiro: tmed con covariable pres_mean
# - Convierte 800 puntos diarios en M curvas de longitud L
# - Etapa 1: representación en base (Fourier / B-spline)
# - Etapa 2: GP sobre coeficientes (u_k) con entradas a nivel de curva
# - Predicción: Escenario B (sin obs) y Escenario A (obs parciales)
# Salidas: PNG + CSV en el directorio de trabajo
############################################################

# -----------------------------
# 0) Paquetes (sin gridExtra)
# -----------------------------
pkgs <- c("fda", "ggplot2", "dplyr", "tidyr", "DiceKriging")
need <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(need) > 0) {
  install.packages(need, repos = "https://cloud.r-project.org")
}
library(fda)
library(ggplot2)
library(dplyr)
library(tidyr)
library(DiceKriging)

set.seed(123)

# -----------------------------
# 1) Leer datos (800 dias)
# -----------------------------
FILE_IN <- "retiro_3195_daily_800_clean.csv"
if (!file.exists(FILE_IN)) {
  stop(paste0("No existe: ", FILE_IN, "\n",
              "Archivos CSV en el directorio:\n",
              paste(list.files(pattern="\\.csv$", ignore.case=TRUE), collapse="\n")))
}

df <- read.csv(FILE_IN, stringsAsFactors = FALSE)

# detectar columna fecha
date_candidates <- c("fecha", "Fecha", "FECHA", "date", "Date", "datetime", "Datetime")
date_col <- date_candidates[date_candidates %in% names(df)][1]
if (is.na(date_col)) stop("No encuentro columna de fecha (fecha/FECHA/date/datetime).")

# parse fecha
df[[date_col]] <- as.Date(df[[date_col]])
df <- df %>% arrange(.data[[date_col]])

# detectar temperatura
tmed_candidates <- c("tmed", "tmedc", "tmed_cor", "tmedcor", "tmedcorr", "temp", "temperature")
tmed_col <- tmed_candidates[tmed_candidates %in% names(df)][1]
if (is.na(tmed_col)) stop("No encuentro columna de temperatura (tmed...).")

# detectar presión media (si no existe, la calculamos)
pres_mean_candidates <- c("pres_mean", "presMean", "pres_media", "pres")
presmax_candidates <- c("presMax", "pres_max", "presmax")
presmin_candidates <- c("presMin", "pres_min", "presmin")

pres_mean_col <- pres_mean_candidates[pres_mean_candidates %in% names(df)][1]

if (is.na(pres_mean_col)) {
  pmx <- presmax_candidates[presmax_candidates %in% names(df)][1]
  pmn <- presmin_candidates[presmin_candidates %in% names(df)][1]
  if (is.na(pmx) || is.na(pmn)) {
    stop("No encuentro pres_mean ni (presMax, presMin).")
  }
  df$pres_mean <- (df[[pmx]] + df[[pmn]])/2
  pres_mean_col <- "pres_mean"
}

# quedarnos con primeras 800
df <- df %>% slice(1:800)

# -----------------------------
# 2) Convertir a curvas: ventana L
# -----------------------------
L <- 20              # <-- puedes cambiar: 20 o 24
K <- 11              # nbasis
BASIS_TYPE <- "bspline"  # "fourier" o "bspline"

M <- floor(nrow(df)/L)
N_used <- M * L
df <- df %>% slice(1:N_used)

# matriz Y: L x M (cada columna = una curva)
y_vec <- df[[tmed_col]]
p_vec <- df[[pres_mean_col]]
dates <- df[[date_col]]

Y <- matrix(y_vec, nrow = L, ncol = M)
P <- matrix(p_vec, nrow = L, ncol = M)

# covariables a nivel de curva
mid_idx <- (seq_len(M)-1)*L + ceiling(L/2)
mid_date_num <- as.numeric(dates[mid_idx])            # numérico (días)
mean_pres <- colMeans(P, na.rm = TRUE)

X_curve <- data.frame(
  mid_date = mid_date_num,
  mean_pres = mean_pres
)

# escalar covariables (se hará con parámetros del train)
scale_with_train <- function(x_train, x_new){
  mu <- apply(x_train, 2, mean)
  sdv <- apply(x_train, 2, sd)
  sdv[sdv == 0] <- 1
  list(
    train = sweep(sweep(x_train, 2, mu, "-"), 2, sdv, "/"),
    new   = sweep(sweep(x_new,   2, mu, "-"), 2, sdv, "/"),
    mu = mu, sd = sdv
  )
}

# -----------------------------
# 3) Split 7:3 (a nivel de curva)
# -----------------------------
n_train <- floor(0.7 * M)
train_idx <- sort(sample.int(M, n_train))
test_idx  <- setdiff(seq_len(M), train_idx)

Y_tr <- Y[, train_idx, drop=FALSE]
Y_te <- Y[, test_idx,  drop=FALSE]

X_tr_raw <- as.matrix(X_curve[train_idx, , drop=FALSE])
X_te_raw <- as.matrix(X_curve[test_idx,  , drop=FALSE])

sc <- scale_with_train(X_tr_raw, X_te_raw)
X_tr <- sc$train
X_te <- sc$new

# -----------------------------
# 4) Base y suavizado (Etapa 1)
# -----------------------------
t_grid <- 1:L

make_basis <- function(L, K, type = c("bspline","fourier")){
  type <- match.arg(type)
  if (type == "fourier") {
    create.fourier.basis(rangeval = c(1, L), nbasis = K, period = L)
  } else {
    create.bspline.basis(rangeval = c(1, L), nbasis = K, norder = 4)
  }
}

basisobj <- make_basis(L, K, BASIS_TYPE)

# seleccionar lambda (simple: grid y GCV promedio en train)
lambda_grid <- 10^seq(-6, 2, length.out = 25)

avg_gcv_for_lambda <- function(lambda){
  fdParobj <- fdPar(basisobj, Lfdobj = int2Lfd(2), lambda = lambda)
  sb <- smooth.basis(t_grid, Y_tr, fdParobj)
  mean(sb$gcv, na.rm = TRUE)
}

gcv_vals <- sapply(lambda_grid, avg_gcv_for_lambda)
lambda_best <- lambda_grid[which.min(gcv_vals)]

fdPar_best <- fdPar(basisobj, Lfdobj = int2Lfd(2), lambda = lambda_best)

# suavizar curvas train y test
sb_tr <- smooth.basis(t_grid, Y_tr, fdPar_best)
sb_te <- smooth.basis(t_grid, Y_te, fdPar_best)

fd_tr <- sb_tr$fd
fd_te <- sb_te$fd

coef_tr <- fd_tr$coefs      # K x n_train
coef_te <- fd_te$coefs      # K x n_test

# media (coeficientes) y residuos u
mu_coef <- rowMeans(coef_tr)
U_tr <- sweep(coef_tr, 1, mu_coef, "-")   # K x n_train
U_te <- sweep(coef_te, 1, mu_coef, "-")   # K x n_test (solo para evaluar)

# ruido (sigma^2) aproximado: residual puntual en train (usando smooth)
Yhat_tr_smooth <- eval.fd(t_grid, fd_tr)  # L x n_train
sigma2_hat <- mean((Y_tr - Yhat_tr_smooth)^2, na.rm = TRUE)

# -----------------------------
# 5) GP sobre coeficientes (Etapa 2)
# -----------------------------
fit_gp_per_k <- function(U_k, X_tr){
  # U_k: vector length n_train
  km(
    design = X_tr,
    response = as.numeric(U_k),
    covtype = "gauss",
    nugget.estim = TRUE,
    control = list(trace = FALSE)
  )
}

gp_models <- vector("list", K)
for (k in 1:K) {
  gp_models[[k]] <- fit_gp_per_k(U_tr[k, ], X_tr)
}

predict_gp_per_k <- function(model, X_new){
  pr <- predict(model, newdata = X_new, type = "UK", se.compute = TRUE)
  list(mean = as.numeric(pr$mean), sd = as.numeric(pr$sd))
}

# coef prior (Escenario B) para test
u_mean_te <- matrix(NA_real_, nrow = K, ncol = ncol(Y_te))
u_var_te  <- matrix(NA_real_, nrow = K, ncol = ncol(Y_te))

for (k in 1:K) {
  pr <- predict_gp_per_k(gp_models[[k]], X_te)
  u_mean_te[k, ] <- pr$mean
  u_var_te[k, ]  <- (pr$sd)^2
}

coef_prior_te <- sweep(u_mean_te, 1, mu_coef, "+")  # K x n_test

# reconstrucción Escenario B (sin obs)
fd_prior_te <- fd(coef_prior_te, basisobj)
Yhat_te_B <- eval.fd(t_grid, fd_prior_te)           # L x n_test

# Para train (in-sample) solo para tener métricas comparables
u_mean_tr <- matrix(NA_real_, nrow = K, ncol = ncol(Y_tr))
u_var_tr  <- matrix(NA_real_, nrow = K, ncol = ncol(Y_tr))
for (k in 1:K) {
  pr <- predict_gp_per_k(gp_models[[k]], X_tr)
  u_mean_tr[k, ] <- pr$mean
  u_var_tr[k, ]  <- (pr$sd)^2
}
coef_prior_tr <- sweep(u_mean_tr, 1, mu_coef, "+")
fd_prior_tr <- fd(coef_prior_tr, basisobj)
Yhat_tr_B <- eval.fd(t_grid, fd_prior_tr)

# -----------------------------
# 6) Escenario A: actualizar coef con obs parciales
# -----------------------------
Phi_all <- eval.basis(t_grid, basisobj)  # L x K

update_coef_with_partial_obs <- function(y_obs, idx_obs, c_prior, v_prior, sigma2){
  # y_obs: vector
  # idx_obs: indices in 1..L
  Phi_obs <- Phi_all[idx_obs, , drop=FALSE]  # |obs| x K
  v_prior[v_prior <= 1e-12] <- 1e-12
  
  A <- (t(Phi_obs) %*% Phi_obs) / sigma2 + diag(1/v_prior, K)
  b <- (t(Phi_obs) %*% y_obs) / sigma2 + c_prior / v_prior
  c_post <- solve(A, b)
  
  # var approx for yhat (diagonal)
  Ainv <- solve(A)
  y_var <- diag(Phi_all %*% Ainv %*% t(Phi_all)) + sigma2
  
  list(c_post = as.numeric(c_post), y_var = y_var)
}

p_obs <- 0.30
n_obs <- max(2, floor(L * p_obs))
idx_obs <- 1:n_obs

Yhat_te_A <- matrix(NA_real_, nrow = L, ncol = ncol(Y_te))
Ysd_te_A  <- matrix(NA_real_, nrow = L, ncol = ncol(Y_te))

for (j in 1:ncol(Y_te)) {
  y_obs <- Y_te[idx_obs, j]
  c_prior <- coef_prior_te[, j]
  v_prior <- u_var_te[, j]  # aproximación (indep. por coef)
  up <- update_coef_with_partial_obs(y_obs, idx_obs, c_prior, v_prior, sigma2_hat)
  fd_post <- fd(matrix(up$c_post, nrow=K, ncol=1), basisobj)
  Yhat_te_A[, j] <- eval.fd(t_grid, fd_post)
  Ysd_te_A[, j]  <- sqrt(pmax(up$y_var, 0))
}

# -----------------------------
# 7) Métricas
# -----------------------------
metrics <- function(y, yhat){
  y <- as.numeric(y); yhat <- as.numeric(yhat)
  mse <- mean((y - yhat)^2, na.rm=TRUE)
  mae <- mean(abs(y - yhat), na.rm=TRUE)
  sst <- sum((y - mean(y, na.rm=TRUE))^2, na.rm=TRUE)
  sse <- sum((y - yhat)^2, na.rm=TRUE)
  r2 <- ifelse(sst > 0, 1 - sse/sst, NA_real_)
  c(MSE=mse, MAE=mae, R2=r2)
}

# agregado por puntos (train/test)
met_tr_B <- metrics(Y_tr, Yhat_tr_B)
met_te_B <- metrics(Y_te, Yhat_te_B)
met_te_A <- metrics(Y_te, Yhat_te_A)

tabla <- data.frame(
  Modelo = c("GPFR-EscenarioB", "GPFR-EscenarioA"),
  MSE_train = c(met_tr_B["MSE"], NA),
  MAE_train = c(met_tr_B["MAE"], NA),
  R2_train  = c(met_tr_B["R2"],  NA),
  MSE_test  = c(met_te_B["MSE"], met_te_A["MSE"]),
  MAE_test  = c(met_te_B["MAE"], met_te_A["MAE"]),
  R2_test   = c(met_te_B["R2"],  met_te_A["R2"])
)

# -----------------------------
# 8) Guardar CSV (en el directorio actual)
# -----------------------------
write.csv(tabla, "Tabla_4_3_1_metricas_GPFR_tmed.csv", row.names = FALSE)

# guardar predicciones (test)
pred_te_B <- data.frame(
  curve_id = rep(seq_len(ncol(Y_te)), each=L),
  t = rep(t_grid, times=ncol(Y_te)),
  y = as.vector(Y_te),
  yhat = as.vector(Yhat_te_B)
)
write.csv(pred_te_B, "pred_GPFR_tmed_test_EscenarioB.csv", row.names = FALSE)

pred_te_A <- data.frame(
  curve_id = rep(seq_len(ncol(Y_te)), each=L),
  t = rep(t_grid, times=ncol(Y_te)),
  y = as.vector(Y_te),
  yhat = as.vector(Yhat_te_A),
  ylo = as.vector(Yhat_te_A - 1.96*Ysd_te_A),
  yhi = as.vector(Yhat_te_A + 1.96*Ysd_te_A)
)
write.csv(pred_te_A, "pred_GPFR_tmed_test_EscenarioA.csv", row.names = FALSE)

# -----------------------------
# 9) Figuras (una curva representativa)
# -----------------------------
pick_one_curve <- function(Ytrue, Yhat, Ysd=NULL, title){
  j <- sample.int(ncol(Ytrue), 1)
  dfp <- data.frame(
    t = t_grid,
    y = Ytrue[,j],
    yhat = Yhat[,j]
  )
  if (!is.null(Ysd)) {
    dfp$ylo <- Yhat[,j] - 1.96*Ysd[,j]
    dfp$yhi <- Yhat[,j] + 1.96*Ysd[,j]
  }
  g <- ggplot(dfp, aes(x=t)) +
    geom_point(aes(y=y), size=1.6) +
    geom_line(aes(y=yhat), linewidth=0.9) +
    labs(title=title, x="t (índice dentro de la curva)", y="tmed (°C)") +
    theme_bw()
  if (!is.null(Ysd)) {
    g <- g + geom_ribbon(aes(ymin=ylo, ymax=yhi), alpha=0.25)
  }
  g
}

g_train <- pick_one_curve(Y_tr, Yhat_tr_B, title = "Entrenamiento (GPFR) - tmed - Escenario B")
g_testB <- pick_one_curve(Y_te, Yhat_te_B, title = "Prueba (GPFR) - tmed - Escenario B")
g_testA <- pick_one_curve(Y_te, Yhat_te_A, Ysd_te_A, title = "Prueba (GPFR) - tmed - Escenario A (con banda 95%)")

ggsave("Fig_4_3_1a_GPFR_tmed_train_EscB.png", g_train, width=10, height=5, dpi=150)
ggsave("Fig_4_3_1b_GPFR_tmed_test_EscB.png",  g_testB, width=10, height=5, dpi=150)
ggsave("Fig_4_3_1c_GPFR_tmed_test_EscA.png",  g_testA, width=10, height=5, dpi=150)

# -----------------------------
# 10) Mensajes finales
# -----------------------------
cat("OK\n")
cat("lambda_best =", lambda_best, "\n")
print(tabla)
cat("Archivos generados:\n",
    " - Tabla_4_3_1_metricas_GPFR_tmed.csv\n",
    " - pred_GPFR_tmed_test_EscenarioB.csv\n",
    " - pred_GPFR_tmed_test_EscenarioA.csv\n",
    " - Fig_4_3_1a_GPFR_tmed_train_EscB.png\n",
    " - Fig_4_3_1b_GPFR_tmed_test_EscB.png\n",
    " - Fig_4_3_1c_GPFR_tmed_test_EscA.png\n")
