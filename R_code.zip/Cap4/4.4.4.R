############################################################
# 4.3.4 GP multivariante (RBF) - Simulación multivariante
# Salidas:
#  - Fig_4_3_4a_GP_sim_multivar_train.png
#  - Fig_4_3_4b_GP_sim_multivar_test.png
#  - pred_GP_sim_multivar_train.csv / pred_GP_sim_multivar_test.csv
#  - Tabla_4_3_4_metricas_GP_sim_multivar.csv
############################################################

rm(list = ls())

# -----------------------------
# 0) Paquetes mínimos
# -----------------------------
if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
library(ggplot2)

set.seed(123)

# -----------------------------
# 1) Cargar o generar datos
# -----------------------------
train_file <- "sim_data_train.csv"
test_file  <- "sim_data_test.csv"

generate_sim_data <- function(t_vals, n_batches, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  # omega ~ U(0,3)
  omega <- runif(length(t_vals) * n_batches, min = 0, max = 3)
  t_rep <- rep(t_vals, times = n_batches)
  
  # Generador (según tu capítulo)
  y  <- sin(t_rep^2) - t_rep + 0.2 * omega
  x1 <- t_rep^3 + exp(2 * t_rep) + omega
  x2 <- tan(t_rep^3) + 0.2 * omega
  
  data.frame(t = t_rep, x1 = x1, x2 = x2, y = y)
}

if (file.exists(train_file) && file.exists(test_file)) {
  df_tr <- read.csv(train_file)
  df_te <- read.csv(test_file)
} else {
  # Diseño: train 70 t (uniformes), 20 lotes => 1400
  t_train <- seq(-3, 3, length.out = 70)
  df_tr <- generate_sim_data(t_train, n_batches = 20, seed = 123)
  
  # Test: 30 t (uniformes), 20 lotes => 600
  t_test <- seq(-3, 3, length.out = 30)
  df_te <- generate_sim_data(t_test, n_batches = 20, seed = 456)
  
  write.csv(df_tr, train_file, row.names = FALSE)
  write.csv(df_te, test_file, row.names = FALSE)
}

# Verificación de columnas esperadas
need_cols <- c("t", "x1", "x2", "y")
missing_tr <- setdiff(need_cols, names(df_tr))
missing_te <- setdiff(need_cols, names(df_te))
if (length(missing_tr) > 0) stop(paste("Faltan columnas en train:", paste(missing_tr, collapse = ", ")))
if (length(missing_te) > 0) stop(paste("Faltan columnas en test:", paste(missing_te, collapse = ", ")))

# -----------------------------
# 2) Estandarizar entradas (con stats de train)
# -----------------------------
Xtr_raw <- as.matrix(df_tr[, c("t", "x1", "x2")])
Xte_raw <- as.matrix(df_te[, c("t", "x1", "x2")])

mu <- colMeans(Xtr_raw)
sdv <- apply(Xtr_raw, 2, sd)
sdv[sdv == 0] <- 1

scale_X <- function(X) {
  sweep(sweep(X, 2, mu, "-"), 2, sdv, "/")
}

Xtr <- scale_X(Xtr_raw)
Xte <- scale_X(Xte_raw)

ytr <- as.numeric(df_tr$y)
yte <- as.numeric(df_te$y)

# -----------------------------
# 3) GP (RBF) desde cero: NLL + Cholesky
# -----------------------------
sq_dist <- function(A, B) {
  # retorna matriz de distancias cuadradas entre filas
  A2 <- rowSums(A^2)
  B2 <- rowSums(B^2)
  D2 <- outer(A2, B2, "+") - 2 * (A %*% t(B))
  pmax(D2, 0)
}

rbf_kernel <- function(A, B, ell, sf2) {
  # ARD: ell vector (d,)
  A_scaled <- sweep(A, 2, ell, "/")
  B_scaled <- sweep(B, 2, ell, "/")
  D2 <- sq_dist(A_scaled, B_scaled)
  sf2 * exp(-0.5 * D2)
}

gp_fit <- function(X, y, jitter = 1e-8) {
  n <- nrow(X)
  d <- ncol(X)
  
  # params: log(ell_1..ell_d), log(sf2), log(sn2)
  init_ell <- rep(1, d)
  init_sf2 <- var(y)
  init_sn2 <- 0.05 * var(y)
  
  theta0 <- c(log(init_ell), log(init_sf2), log(init_sn2))
  
  nll <- function(theta) {
    ell <- exp(theta[1:d])
    sf2 <- exp(theta[d + 1])
    sn2 <- exp(theta[d + 2])
    
    K <- rbf_kernel(X, X, ell, sf2)
    diag(K) <- diag(K) + sn2 + jitter
    
    L <- tryCatch(chol(K), error = function(e) NULL)
    if (is.null(L)) return(1e25)
    
    # alpha = K^{-1} y via chol
    alpha <- backsolve(L, forwardsolve(t(L), y))
    val <- 0.5 * sum(y * alpha) + sum(log(diag(L))) + 0.5 * n * log(2*pi)
    if (!is.finite(val)) val <- 1e25
    val
  }
  
  # bounds (en log-espacio) para evitar degeneraciones
  lower <- c(rep(log(1e-3), d), log(1e-6), log(1e-8))
  upper <- c(rep(log(1e3),  d), log(1e6),  log(1e1))
  
  opt <- optim(
    par = theta0,
    fn  = nll,
    method = "L-BFGS-B",
    lower = lower,
    upper = upper,
    control = list(maxit = 200)
  )
  
  theta_hat <- opt$par
  ell <- exp(theta_hat[1:d])
  sf2 <- exp(theta_hat[d + 1])
  sn2 <- exp(theta_hat[d + 2])
  
  # Precompute para predicción
  K <- rbf_kernel(X, X, ell, sf2)
  diag(K) <- diag(K) + sn2 + jitter
  L <- chol(K)
  alpha <- backsolve(L, forwardsolve(t(L), y))
  
  list(ell = ell, sf2 = sf2, sn2 = sn2, jitter = jitter,
       X = X, y = y, L = L, alpha = alpha,
       opt_value = opt$value, opt_convergence = opt$convergence)
}

gp_predict <- function(fit, Xnew, return_obs_var = TRUE) {
  X <- fit$X
  L <- fit$L
  alpha <- fit$alpha
  ell <- fit$ell
  sf2 <- fit$sf2
  sn2 <- fit$sn2
  jitter <- fit$jitter
  
  Kxs <- rbf_kernel(X, Xnew, ell, sf2)           # (n x n*)
  mu  <- as.numeric(t(Kxs) %*% alpha)            # (n*)
  
  # var_f = kss - v^T v, where v = L^{-1} Kxs
  v <- forwardsolve(t(L), Kxs)                   # (n x n*)
  var_f <- rep(sf2, ncol(Xnew)) - colSums(v^2)
  var_f <- pmax(var_f, 0)
  
  if (return_obs_var) {
    var_y <- var_f + sn2
    sd_y  <- sqrt(pmax(var_y, 0))
    list(mean = mu, sd = sd_y, var_f = var_f)
  } else {
    sd_f <- sqrt(var_f)
    list(mean = mu, sd = sd_f, var_f = var_f)
  }
}

# -----------------------------
# 4) Ajustar GP y predecir
# -----------------------------
fit <- gp_fit(Xtr, ytr, jitter = 1e-8)

pred_tr <- gp_predict(fit, Xtr, return_obs_var = TRUE)
pred_te <- gp_predict(fit, Xte, return_obs_var = TRUE)

make_pred_df <- function(df, pred) {
  yhat <- pred$mean
  sdp  <- pred$sd
  data.frame(
    t   = df$t,
    x1  = df$x1,
    x2  = df$x2,
    y   = df$y,
    yhat = yhat,
    ylo  = yhat - 1.96 * sdp,
    yhi  = yhat + 1.96 * sdp
  )
}

df_pred_tr <- make_pred_df(df_tr, pred_tr)
df_pred_te <- make_pred_df(df_te, pred_te)

write.csv(df_pred_tr, "pred_GP_sim_multivar_train.csv", row.names = FALSE)
write.csv(df_pred_te, "pred_GP_sim_multivar_test.csv",  row.names = FALSE)

# -----------------------------
# 5) Métricas (por observación)
# -----------------------------
metrics <- function(y, yhat) {
  mse <- mean((y - yhat)^2)
  mae <- mean(abs(y - yhat))
  sst <- sum((y - mean(y))^2)
  sse <- sum((y - yhat)^2)
  r2  <- 1 - sse / sst
  c(MSE = mse, MAE = mae, R2 = r2)
}

m_tr <- metrics(df_pred_tr$y, df_pred_tr$yhat)
m_te <- metrics(df_pred_te$y, df_pred_te$yhat)

tabla <- data.frame(
  Modelo   = "GP multivariante (RBF)",
  MSE_train = m_tr["MSE"],
  MAE_train = m_tr["MAE"],
  R2_train  = m_tr["R2"],
  MSE_test  = m_te["MSE"],
  MAE_test  = m_te["MAE"],
  R2_test   = m_te["R2"]
)

write.csv(tabla, "Tabla_4_3_4_metricas_GP_sim_multivar.csv", row.names = FALSE)

# -----------------------------
# 6) Curva y(t): agregación por t para visualización
# (media por t de yhat/ylo/yhi para evitar distorsión por lotes)
# -----------------------------
agg_curve <- function(df_pred) {
  agg <- aggregate(cbind(yhat, ylo, yhi) ~ t, data = df_pred, FUN = mean)
  agg <- agg[order(agg$t), ]
  agg
}

curve_tr <- agg_curve(df_pred_tr)
curve_te <- agg_curve(df_pred_te)

# -----------------------------
# 7) Plot (train/test): puntos + curva agregada + banda 95%
# -----------------------------
plot_curve <- function(df_points, df_curve, title, out_png) {
  p <- ggplot() +
    geom_ribbon(
      data = df_curve,
      aes(x = t, ymin = ylo, ymax = yhi),
      fill = "grey70", alpha = 0.5
    ) +
    geom_point(
      data = df_points,
      aes(x = t, y = y),
      size = 1.2, alpha = 0.8
    ) +
    geom_line(
      data = df_curve,
      aes(x = t, y = yhat),
      linewidth = 1.0
    ) +
    labs(
      title = title,
      x = "t",
      y = "y"
    ) +
    theme_bw(base_size = 14)
  
  ggsave(out_png, p, width = 12, height = 6, dpi = 150)
  invisible(p)
}

plot_curve(
  df_points = df_tr,
  df_curve  = curve_tr,
  title     = "Entrenamiento (GP multivariante - RBF) - Datos simulados multivariantes",
  out_png   = "Fig_4_3_4a_GP_sim_multivar_train.png"
)

plot_curve(
  df_points = df_te,
  df_curve  = curve_te,
  title     = "Prueba (GP multivariante - RBF) - Datos simulados multivariantes (banda 95%)",
  out_png   = "Fig_4_3_4b_GP_sim_multivar_test.png"
)

# -----------------------------
# 8) Imprimir resumen en consola
# -----------------------------
cat("====================================================\n")
cat("GP multivariante (RBF) ajustado.\n")
cat("ell (ARD):", paste(round(fit$ell, 4), collapse = ", "), "\n")
cat("sf2:", signif(fit$sf2, 4), "  sn2:", signif(fit$sn2, 4), "\n")
cat("Convergencia optim:", fit$opt_convergence, "  NLL:", signif(fit$opt_value, 6), "\n\n")
print(tabla)
cat("Archivos generados en el directorio actual:\n")
cat(" - Fig_4_3_4a_GP_sim_multivar_train.png\n")
cat(" - Fig_4_3_4b_GP_sim_multivar_test.png\n")
cat(" - pred_GP_sim_multivar_train.csv\n")
cat(" - pred_GP_sim_multivar_test.csv\n")
cat(" - Tabla_4_3_4_metricas_GP_sim_multivar.csv\n")
cat("====================================================\n")
