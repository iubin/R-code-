# =========================
# Build Table 4.xx for Section 4.4 (Word)
# =========================
install.packages("flextable")
library(dplyr)
library(flextable)
library(officer)

infile <- "ch4_4_metrics_gpfr_multivar.csv"
df <- read.csv(infile)

# Add covariate description (edit wording if you want)
df <- df %>%
  mutate(
    Entradas = case_when(
      model == "M0_meanCurve" ~ "— (baseline)",
      model == "M1_GPFR_F"    ~ "F",
      model == "M2_GPFR_WS"   ~ "W+S",
      model == "M3_GPFR_FWS"  ~ "F+W+S",
      TRUE ~ ""
    ),
    Modelo = model
  ) %>%
  select(Modelo, Entradas, rmse, mae, r2, day_mae, coverage95, width95)

# Replace NA by "—" for presentation
df_fmt <- df %>%
  mutate(
    across(c(rmse, mae, day_mae, width95), ~ round(., 1)),
    r2 = round(r2, 4),
    coverage95 = round(coverage95, 4)
  )

# Find best values (for bolding)
best_rmse   <- which.min(df$rmse)
best_mae    <- which.min(df$mae)
best_r2     <- which.max(df$r2)
best_daymae <- which.min(df$day_mae)

# Coverage: closest to 0.95 among non-NA
cov_ok <- which(!is.na(df$coverage95))
best_cov <- cov_ok[which.min(abs(df$coverage95[cov_ok] - 0.95))]

# Width: smallest among non-NA
wid_ok <- which(!is.na(df$width95))
best_width <- wid_ok[which.min(df$width95[wid_ok])]

# Build flextable
ft <- flextable(df_fmt)
ft <- set_header_labels(
  ft,
  Modelo    = "Modelo",
  Entradas  = "Entradas",
  rmse      = "RMSE ↓",
  mae       = "MAE ↓",
  r2        = "R² ↑",
  day_mae   = "day-MAE ↓",
  coverage95= "Coverage95 (≈0.95)",
  width95   = "Width95 ↓"
)

ft <- theme_booktabs(ft)
ft <- autofit(ft)

# Bold best cells
ft <- bold(ft, i = best_rmse,   j = "rmse",   bold = TRUE)
ft <- bold(ft, i = best_mae,    j = "mae",    bold = TRUE)
ft <- bold(ft, i = best_r2,     j = "r2",     bold = TRUE)
ft <- bold(ft, i = best_daymae, j = "day_mae",bold = TRUE)
ft <- bold(ft, i = best_cov,    j = "coverage95", bold = TRUE)
ft <- bold(ft, i = best_width,  j = "width95",    bold = TRUE)

# Convert NA to dash visually (optional)
ft <- colformat_num(ft, j = c("rmse","mae","day_mae","width95"), digits = 1)
ft <- colformat_num(ft, j = c("r2","coverage95"), digits = 4)

# Export to Word
doc <- read_docx()
doc <- body_add_par(doc,
                    "Tabla 4.xx. Resultados en test para la predicción de curvas diarias (España, OPDS).",
                    style = "Normal"
)
doc <- body_add_flextable(doc, ft)
doc <- body_add_par(doc,
                    "Nota: Coverage95 y Width95 no aplican al baseline (M0). La mejor cifra por columna se resalta en negrita.",
                    style = "Normal"
)

print(doc, target = "Tabla_4xx_44_resultados.docx")
