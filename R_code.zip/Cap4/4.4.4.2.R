############################################################
# Robust daily-curve building + GPFR (basis expansion + GP on coefs)
############################################################

suppressPackageStartupMessages({
  library(data.table)
  library(lubridate)
  library(dplyr)
  library(tidyr)
  library(fda)
  library(DiceKriging)
  library(ggplot2)
})

#============================
# 0) Config
#============================
OPDS_PATH <- "opds_time_series_60min_singleindex_2020-10-06.csv"

START_DATE <- NULL  # e.g. "2020-01-01" ; keep NULL to disable
END_DATE   <- NULL  # e.g. "2021-01-01" ; keep NULL to disable

TEST_FRAC <- 0.20              # chronological split
MAX_MISS_LOAD_PER_DAY <- 2     # allow up to 2 missing hours in load, then impute
K_BASIS   <- 10
NORDER    <- 4
LAMBDA    <- 1e-2
SEED      <- 123
set.seed(SEED)

#============================
# 1) Utils
#============================
zscore_fit <- function(x) list(mu = mean(x, na.rm=TRUE), sd = sd(x, na.rm=TRUE))
zscore_apply <- function(x, fit) (x - fit$mu) / ifelse(is.na(fit$sd) || fit$sd == 0, 1, fit$sd)

rmse <- function(a,b) sqrt(mean((a-b)^2, na.rm=TRUE))
mae  <- function(a,b) mean(abs(a-b), na.rm=TRUE)
rsq  <- function(a,b) {
  a <- as.vector(a); b <- as.vector(b)
  ss_res <- sum((a-b)^2, na.rm=TRUE)
  ss_tot <- sum((a-mean(a, na.rm=TRUE))^2, na.rm=TRUE)
  if (ss_tot == 0) return(NA_real_)
  1 - ss_res/ss_tot
}

safe_split <- function(M, test_frac=0.2) {
  stopifnot(M > 0)
  n_test  <- max(1, ceiling(M * test_frac))
  n_train <- M - n_test
  if (n_train < 1) stop(sprintf("有效天数 M=%d 太少，无法划分训练/测试。", M))
  list(idx_train = seq_len(n_train), idx_test = (n_train + 1):M)
}

pick_col <- function(nms, candidates) {
  hit <- candidates[candidates %in% nms]
  if (length(hit) == 0) return(NA_character_)
  hit[1]
}

# Robust UTC parser (handles 'T', 'Z', milliseconds)
parse_utc_robust <- function(x) {
  x <- as.character(x)
  x <- gsub("Z$", "", x)
  x <- gsub("T", " ", x)
  x <- gsub("\\.\\d+$", "", x)  # drop milliseconds if present
  suppressWarnings(ymd_hms(x, tz="UTC"))
}

# Linear imputation within a 24-length vector (rule=2 extends ends)
impute_linear_24 <- function(x) {
  if (all(is.na(x))) return(rep(NA_real_, length(x)))
  idx <- which(!is.na(x))
  if (length(idx) == 1) return(rep(x[idx], length(x)))
  approx(x = idx, y = x[idx], xout = seq_along(x), method = "linear", rule = 2)$y
}

#============================
# 2) Read OPDS (Spain cols) robust to naming variants
#============================
read_spain_opds <- function(path) {
  hdr <- names(fread(path, nrows=0))
  
  col_utc <- pick_col(hdr, c("utc_timestamp","UTC_timestamp","utc_time","time","timestamp"))
  col_load <- pick_col(hdr, c("ES_load_actual_entsoe_transparency",
                              "ES_load_actual_entsoe_transparency_MW",
                              "ES_load_actual", "ES_load"))
  col_fore <- pick_col(hdr, c("ES_load_forecast_entsoe_transparency",
                              "ES_load_forecast_entsoe_transparency_MW",
                              "ES_load_forecast", "ES_forecast"))
  col_solar <- pick_col(hdr, c("ES_solar_generation_actual",
                               "ES_solar_generation_actual_MW",
                               "ES_solar_generation"))
  col_wind <- pick_col(hdr, c("ES_wind_onshore_generation_actual",
                              "ES_wind_onshore_generation_actual_MW",
                              "ES_wind_onshore_generation"))
  
  needed <- c(col_utc, col_load, col_fore, col_solar, col_wind)
  if (any(is.na(needed))) {
    stop("未找到所需列。请检查 CSV 表头是否包含 Spain 的 load/forecast/solar/wind 字段。")
  }
  
  dt <- fread(path, select = needed, showProgress = TRUE)
  setnames(dt, old = needed, new = c("utc_raw","load","forecast","solar","wind"))
  dt[, utc := parse_utc_robust(utc_raw)]
  dt[, utc_raw := NULL]
  dt
}

dt <- read_spain_opds(OPDS_PATH)

# If parsing failed badly, stop early with diagnostics
na_utc <- sum(is.na(dt$utc))
if (na_utc > 0) {
  cat("WARNING: NA utc after parsing:", na_utc, "out of", nrow(dt), "\n")
  cat("Example rows with NA utc (first 5):\n")
  print(head(dt[is.na(utc)], 5))
}
dt <- dt %>% filter(!is.na(utc))
if (nrow(dt) == 0) stop("utc_timestamp 全部解析失败。请把文件前几行表头和时间戳样例发我。")

cat("Raw rows:", nrow(dt), "\n")
cat("Time range:", as.character(min(dt$utc)), "~", as.character(max(dt$utc)), "\n")

# Optional time window (after we know real range)
if (!is.null(START_DATE) && !is.null(END_DATE)) {
  dt <- dt %>%
    filter(utc >= ymd(START_DATE, tz="UTC"),
           utc <  ymd(END_DATE,   tz="UTC"))
  cat("After window rows:", nrow(dt), "\n")
  if (nrow(dt) == 0) stop("过滤时间窗口后数据为空。请调整 START_DATE/END_DATE。")
}

#============================
# 3) Build daily curves (24 points) robustly
#    - aggregate duplicates (date,hour)
#    - complete missing hours 0..23
#    - allow small missing load and impute
#============================
dt2 <- dt %>%
  mutate(date = as.Date(utc),
         hour = lubridate::hour(utc)) %>%
  filter(!is.na(date), !is.na(hour), hour %in% 0:23) %>%
  group_by(date, hour) %>%
  summarise(
    load     = mean(load,     na.rm = TRUE),
    forecast = mean(forecast, na.rm = TRUE),
    solar    = mean(solar,    na.rm = TRUE),
    wind     = mean(wind,     na.rm = TRUE),
    .groups  = "drop"
  ) %>%
  group_by(date) %>%
  tidyr::complete(hour = 0:23) %>%   # ensure 24 rows per day
  arrange(date, hour) %>%
  ungroup()

# day-level missing stats
day_stat <- dt2 %>%
  group_by(date) %>%
  summarise(
    miss_load = sum(is.na(load)),
    .groups="drop"
  )

cat("Days total:", nrow(day_stat), "\n")
cat("Days with 0 missing load:", sum(day_stat$miss_load == 0), "\n")
cat("Days with <= ", MAX_MISS_LOAD_PER_DAY, " missing load:", sum(day_stat$miss_load <= MAX_MISS_LOAD_PER_DAY), "\n")

# keep days with tolerable missing load
keep_days <- day_stat %>%
  filter(miss_load <= MAX_MISS_LOAD_PER_DAY) %>%
  pull(date)

dt2 <- dt2 %>% filter(date %in% keep_days)
if (nrow(dt2) == 0) {
  stop("仍然没有可用日期。建议：1) 取消时间窗口；2) 把 MAX_MISS_LOAD_PER_DAY 调大到 4 或 6；3) 检查 Spain load 列是否几乎全 NA。")
}

# impute within each day (load mandatory; others optional)
dt2 <- dt2 %>%
  group_by(date) %>%
  mutate(
    load_imp     = impute_linear_24(load),
    forecast_imp = impute_linear_24(forecast),
    wind_imp     = impute_linear_24(wind),
    solar_imp    = impute_linear_24(solar)
  ) %>%
  ungroup()

# Build curve matrix (M x 24)
curves <- dt2 %>%
  select(date, hour, load_imp) %>%
  pivot_wider(names_from = hour, values_from = load_imp) %>%
  arrange(date)

Y_mat <- as.matrix(curves %>% select(-date))
dates <- curves$date

# Daily covariates: one row per day (IMPORTANT)
X_day <- dt2 %>%
  group_by(date) %>%
  summarise(
    forecast_mean = mean(forecast_imp, na.rm=TRUE),
    wind_mean     = mean(wind_imp,     na.rm=TRUE),
    solar_mean    = mean(solar_imp,    na.rm=TRUE),
    .groups="drop"
  ) %>%
  mutate(
    across(c(forecast_mean, wind_mean, solar_mean), ~ ifelse(is.nan(.), NA, .)),
    dow = ((lubridate::wday(date) + 5) %% 7) + 1   # Monday=1 ... Sunday=7
  )

# Align X_day order to curves$date (dates)
X_day <- data.frame(date = dates) %>%
  left_join(X_day, by = "date")

# Now alignment must hold
stopifnot(nrow(X_day) == length(dates))
stopifnot(all(X_day$date == dates))


# To ensure all three covariates exist for the main model:
keep2 <- complete.cases(X_day[, c("forecast_mean","wind_mean","solar_mean")])
Y_mat <- Y_mat[keep2, , drop=FALSE]
X_day <- X_day[keep2, , drop=FALSE]
dates <- dates[keep2]

M <- nrow(Y_mat)
cat("Usable complete days after covariate check M =", M, "\n")
if (M < 10) stop("可用天数太少（<10）。建议：取消时间窗口或放宽缺失阈值。")

#============================
# 4) Train/test split (safe)
#============================
sp <- safe_split(M, TEST_FRAC)
idx_train <- sp$idx_train
idx_test  <- sp$idx_test

Y_train <- Y_mat[idx_train, , drop=FALSE]
Y_test  <- Y_mat[idx_test,  , drop=FALSE]
X_train <- X_day[idx_train, ]
X_test  <- X_day[idx_test,  ]

cat("Train days:", nrow(Y_train), " Test days:", nrow(Y_test), "\n")
cat("Train date range:", as.character(min(X_train$date)), "~", as.character(max(X_train$date)), "\n")
cat("Test  date range:", as.character(min(X_test$date)),  "~", as.character(max(X_test$date)), "\n")

#============================
# 5) Standardize covariates (fit on train only)
#============================
fit_fore  <- zscore_fit(X_train$forecast_mean)
fit_wind  <- zscore_fit(X_train$wind_mean)
fit_solar <- zscore_fit(X_train$solar_mean)

X_train_std <- data.frame(
  forecast = zscore_apply(X_train$forecast_mean, fit_fore),
  wind     = zscore_apply(X_train$wind_mean,     fit_wind),
  solar    = zscore_apply(X_train$solar_mean,    fit_solar)
)
X_test_std <- data.frame(
  forecast = zscore_apply(X_test$forecast_mean, fit_fore),
  wind     = zscore_apply(X_test$wind_mean,     fit_wind),
  solar    = zscore_apply(X_test$solar_mean,    fit_solar)
)

make_X <- function(Xstd, mode=c("F","WS","FWS")) {
  mode <- match.arg(mode)
  if (mode == "F")   return(Xstd[, c("forecast"), drop=FALSE])
  if (mode == "WS")  return(Xstd[, c("wind","solar"), drop=FALSE])
  if (mode == "FWS") return(Xstd[, c("forecast","wind","solar"), drop=FALSE])
}

#============================
# 6) Smooth curves with B-splines & get coefficients
#============================
tgrid <- 0:23
basis <- create.bspline.basis(rangeval=c(0,23), nbasis=K_BASIS, norder=NORDER)
fdParobj <- fdPar(basis, Lfdobj=2, lambda=LAMBDA)

smooth_train <- smooth.basis(tgrid, t(Y_train), fdParobj)
coef_train <- t(smooth_train$fd$coefs)  # (M_train x K)

Bmat <- eval.basis(tgrid, basis)        # (24 x K)

#============================
# 7) GP on coefficients (DiceKriging)
#============================
fit_gpfr <- function(Xtr, coef_tr, covtype="matern5_2") {
  K <- ncol(coef_tr)
  models <- vector("list", K)
  for (k in seq_len(K)) {
    models[[k]] <- km(
      design = as.matrix(Xtr),
      response = coef_tr[, k],
      covtype = covtype,
      nugget.estim = TRUE,
      control = list(trace = FALSE)
    )
  }
  models
}

pred_gpfr <- function(models, Xnew) {
  K <- length(models)
  mu <- matrix(NA_real_, nrow=nrow(Xnew), ncol=K)
  va <- matrix(NA_real_, nrow=nrow(Xnew), ncol=K)
  for (k in seq_len(K)) {
    p <- predict(models[[k]], newdata = as.matrix(Xnew), type="UK", se.compute=TRUE)
    mu[,k] <- p$mean
    va[,k] <- (p$sd)^2
  }
  list(mu=mu, va=va)
}

reconstruct_curve <- function(mu_beta, var_beta, Bmat) {
  yhat <- mu_beta %*% t(Bmat)      # (M x 24)
  Bt2  <- (t(Bmat))^2              # (K x 24)
  vhat <- var_beta %*% Bt2         # (M x 24)
  list(mean=yhat, var=vhat)
}

run_one <- function(mode) {
  Xtr <- make_X(X_train_std, mode)
  Xte <- make_X(X_test_std,  mode)
  models <- fit_gpfr(Xtr, coef_train)
  pred   <- pred_gpfr(models, Xte)
  rec    <- reconstruct_curve(pred$mu, pred$va, Bmat)
  list(mode=mode, y_mean=rec$mean, y_sd=sqrt(pmax(rec$var, 0)))
}

res_F   <- run_one("F")
res_WS  <- run_one("WS")
res_FWS <- run_one("FWS")

# Baseline M0: mean daily curve (no uncertainty)
mean_curve <- colMeans(Y_train, na.rm=TRUE)
y_mean_M0 <- matrix(rep(mean_curve, each=nrow(Y_test)), nrow=nrow(Y_test))
y_sd_M0   <- matrix(NA_real_, nrow=nrow(Y_test), ncol=24)

#============================
# 8) Metrics + coverage
#============================
eval_res <- function(y_true, y_pred, y_sd=NULL) {
  out <- list(
    rmse    = rmse(as.vector(y_true), as.vector(y_pred)),
    mae     = mae(as.vector(y_true),  as.vector(y_pred)),
    r2      = rsq(as.vector(y_true),  as.vector(y_pred)),
    day_mae = mean(apply(abs(y_true - y_pred), 1, mean, na.rm=TRUE), na.rm=TRUE)
  )
  if (!is.null(y_sd) && !all(is.na(y_sd))) {
    lo <- y_pred - 1.96*y_sd
    hi <- y_pred + 1.96*y_sd
    out$coverage95 <- mean((y_true >= lo) & (y_true <= hi), na.rm=TRUE)
    out$width95    <- mean(hi - lo, na.rm=TRUE)
  } else {
    out$coverage95 <- NA_real_
    out$width95    <- NA_real_
  }
  out
}

m0   <- eval_res(Y_test, y_mean_M0, y_sd_M0)
mF   <- eval_res(Y_test, res_F$y_mean,   res_F$y_sd)
mWS  <- eval_res(Y_test, res_WS$y_mean,  res_WS$y_sd)
mFWS <- eval_res(Y_test, res_FWS$y_mean, res_FWS$y_sd)

metrics <- rbind(
  data.frame(model="M0_meanCurve", t(unlist(m0))),
  data.frame(model="M1_GPFR_F",    t(unlist(mF))),
  data.frame(model="M2_GPFR_WS",   t(unlist(mWS))),
  data.frame(model="M3_GPFR_FWS",  t(unlist(mFWS)))
)

print(metrics)
write.csv(metrics, "ch4_4_metrics_gpfr_multivar.csv", row.names=FALSE)

#============================
# 9) Plots (example test days)
#============================
plot_one_day <- function(i, y_true, y_mean, y_sd, title="") {
  df <- data.frame(
    hour = 0:23,
    y  = as.numeric(y_true[i,]),
    mu = as.numeric(y_mean[i,]),
    sd = as.numeric(y_sd[i,])
  )
  p <- ggplot(df, aes(x=hour)) +
    geom_line(aes(y=y), linewidth=0.8) +
    geom_line(aes(y=mu), linewidth=0.8, linetype=2) +
    labs(title=title, x="Hour", y="Load")
  if (!all(is.na(df$sd))) {
    p <- p + geom_ribbon(aes(ymin=mu-1.96*sd, ymax=mu+1.96*sd), alpha=0.2)
  }
  p
}

nT <- nrow(Y_test)
pick <- unique(pmin(c(1, floor(nT/2), nT), nT))
if (length(pick) < 3 && nT >= 3) pick <- c(1,2,3)

p1 <- plot_one_day(pick[1], Y_test, res_FWS$y_mean, res_FWS$y_sd,
                   paste0("M3 (F+W+S)  Test day: ", as.character(X_test$date[pick[1]])))
p2 <- plot_one_day(pick[min(2,length(pick))], Y_test, res_FWS$y_mean, res_FWS$y_sd,
                   paste0("M3 (F+W+S)  Test day: ", as.character(X_test$date[pick[min(2,length(pick))]])))
p3 <- plot_one_day(pick[min(3,length(pick))], Y_test, res_FWS$y_mean, res_FWS$y_sd,
                   paste0("M3 (F+W+S)  Test day: ", as.character(X_test$date[pick[min(3,length(pick))]])))

ggsave("ch4_4_example_day1.png", p1, width=7, height=4, dpi=150)
ggsave("ch4_4_example_day2.png", p2, width=7, height=4, dpi=150)
ggsave("ch4_4_example_day3.png", p3, width=7, height=4, dpi=150)

cat("Saved: ch4_4_metrics_gpfr_multivar.csv and ch4_4_example_day*.png\n")

# ==== Extra diagnostics for Chapter 4.4 ====
# Hour-wise MAE and coverage for M3

y_true <- Y_test
y_pred <- res_FWS$y_mean
y_sd   <- res_FWS$y_sd

# Hour-wise MAE
mae_by_hour <- apply(abs(y_true - y_pred), 2, mean, na.rm=TRUE)
df_mae <- data.frame(hour = 0:23, MAE = as.numeric(mae_by_hour))

p_mae <- ggplot(df_mae, aes(x=hour, y=MAE)) +
  geom_line(linewidth=0.8) +
  labs(title="M3 (F+W+S): MAE por hora en test", x="Hour", y="MAE")
ggsave("ch4_4_mae_by_hour_M3.png", p_mae, width=7, height=4, dpi=150)

# Hour-wise coverage (95%)
lo <- y_pred - 1.96*y_sd
hi <- y_pred + 1.96*y_sd
cover_mat <- (y_true >= lo) & (y_true <= hi)
cover_by_hour <- apply(cover_mat, 2, mean, na.rm=TRUE)
df_cov <- data.frame(hour = 0:23, Coverage95 = as.numeric(cover_by_hour))

p_cov <- ggplot(df_cov, aes(x=hour, y=Coverage95)) +
  geom_line(linewidth=0.8) +
  geom_hline(yintercept=0.95, linetype=2) +
  labs(title="M3 (F+W+S): Cobertura por hora (95%)", x="Hour", y="Coverage")
ggsave("ch4_4_coverage_by_hour_M3.png", p_cov, width=7, height=4, dpi=150)

# ---- Export hour-wise diagnostics for thesis ----
diag_hour <- merge(df_mae, df_cov, by="hour")  # hour, MAE, Coverage95
write.csv(diag_hour, "ch4_4_diag_by_hour_M3.csv", row.names=FALSE)

# Identify worst hours (lowest coverage, highest MAE)
worst_cov <- diag_hour[order(diag_hour$Coverage95), ][1:3, ]
worst_mae <- diag_hour[order(-diag_hour$MAE), ][1:3, ]

print("Worst coverage hours (bottom 3):")
print(worst_cov)

print("Highest MAE hours (top 3):")
print(worst_mae)
