# ============================================================
# AEMET (Madrid Retiro 3195) - Daily data downloader + cleaner
# Goal: build an EXACT 800-day daily dataset centered on 2018–2019
# Output:
#   - retiro_3195_daily_800_clean_<window>.csv
#   - retiro_3195_train_560_<window>.csv
#   - retiro_3195_test_240_<window>.csv
# Notes:
#   - Uses AEMET "valores climatológicos diarios" endpoint (daily validated values).
#   - Forces a complete daily date sequence and linearly imputes missing tmed/presMax/presMin.
# ============================================================

# install.packages(c("httr2","jsonlite","dplyr","stringr","tibble","readr","lubridate"), dependencies = TRUE)

library(httr2)
library(jsonlite)
library(dplyr)
library(stringr)
library(tibble)
library(readr)
library(lubridate)

# ----------------------------
# 0) Config
# ----------------------------
BASE <- "https://opendata.aemet.es/opendata/api/"
API_KEY <- Sys.getenv("AEMET_API_KEY")
stopifnot(nchar(API_KEY) > 0)

IDEMA <- "3195"     # Madrid Retiro
SEED_SPLIT <- 1234  # for reproducible 7:3 split (if you choose uniform split later)

# Choose ONE window strategy:
# A) "from_start": start at 2018-01-01 and take 800 consecutive days -> ends in early 2020
# B) "to_end": end at 2019-12-31 and take 800 consecutive days -> starts in late 2017
WINDOW_MODE <- "from_start" 

if (WINDOW_MODE == "from_start") {
  start_date <- as.Date("2018-01-01")
  end_date   <- start_date + 799  # inclusive -> 800 days
} else if (WINDOW_MODE == "to_end") {
  end_date   <- as.Date("2019-12-31")
  start_date <- end_date - 799    # inclusive -> 800 days
} else {
  stop("WINDOW_MODE must be 'from_start' or 'to_end'")
}

cat("Target 800-day window:", as.character(start_date), "~", as.character(end_date), "\n")
stopifnot(as.integer(end_date - start_date) == 799)

# ----------------------------
# 1) HTTP 429 retry + loose JSON parsing
# ----------------------------
req_perform_retry <- function(req, max_tries = 8) {
  for (i in seq_len(max_tries)) {
    resp <- try(req_perform(req), silent = TRUE)
    if (!inherits(resp, "try-error")) return(resp)
    
    msg <- as.character(resp)
    if (str_detect(msg, "HTTP 429")) {
      wait_s <- min(2^(i - 1), 120)
      message(sprintf("HTTP 429: waiting %s seconds then retrying (%s/%s)...", wait_s, i, max_tries))
      Sys.sleep(wait_s)
    } else {
      stop(resp)
    }
  }
  stop("Still getting HTTP 429 after retries. Please wait a few minutes and retry.")
}

resp_body_json_loose <- function(resp) {
  txt <- resp_body_string(resp)
  tryCatch(
    jsonlite::fromJSON(txt, simplifyVector = TRUE),
    error = function(e) stop("Response is not JSON. First 300 chars:\n", substr(txt, 1, 300))
  )
}

aemet_api <- function(path) {
  req <- request(paste0(BASE, path)) |>
    req_url_query(api_key = API_KEY) |>
    req_headers(accept = "application/json, text/plain, */*")
  resp <- req_perform_retry(req)
  resp_body_json_loose(resp)
}

aemet_follow_datos <- function(api_resp) {
  if (is.null(api_resp$estado) || api_resp$estado != 200) {
    stop(sprintf("AEMET error %s: %s", api_resp$estado, api_resp$descripcion))
  }
  req2 <- request(api_resp$datos) |>
    req_headers(accept = "application/json, text/plain, */*")
  resp2 <- req_perform_retry(req2)
  resp_body_json_loose(resp2)
}

# ----------------------------
# 2) Helpers
# ----------------------------
to_num <- function(x) as.numeric(str_replace_all(x, ",", "."))

fmt_utc <- function(d) {
  # AEMET daily endpoint expects "YYYY-MM-DDT00:00:00UTC"
  URLencode(sprintf("%sT00:00:00UTC", format(as.Date(d), "%Y-%m-%d")), reserved = TRUE)
}

make_chunks_6m <- function(start_date, end_date) {
  s <- as.Date(start_date)
  e <- as.Date(end_date)
  out <- list()
  while (s <= e) {
    chunk_end <- min((s %m+% months(6)) - days(1), e)
    out[[length(out) + 1]] <- tibble(start = s, end = chunk_end)
    s <- chunk_end + days(1)
  }
  bind_rows(out)
}

impute_linear <- function(dates, x) {
  t <- as.numeric(dates)
  ok <- !is.na(x)
  if (sum(ok) < 2) stop("Not enough non-missing points to interpolate.")
  x[!ok] <- approx(t[ok], x[ok], xout = t[!ok], rule = 2)$y
  x
}

# ----------------------------
# 3) Download daily data 
# Here we download exactly the chosen 800-day window (in chunks).
# ----------------------------
download_daily_station <- function(idema, start_date, end_date, polite_sleep = 0.8) {
  chunks <- make_chunks_6m(start_date, end_date)
  message("Downloading in chunks:\n", paste(capture.output(print(chunks)), collapse = "\n"))
  
  all_parts <- vector("list", nrow(chunks))
  for (i in seq_len(nrow(chunks))) {
    s <- chunks$start[i]
    e <- chunks$end[i]
    
    path_daily <- paste0(
      "valores/climatologicos/diarios/datos/fechaini/", fmt_utc(s),
      "/fechafin/", fmt_utc(e),
      "/estacion/", idema
    )
    
    message(sprintf("Chunk %d/%d: %s ~ %s", i, nrow(chunks), s, e))
    meta <- aemet_api(path_daily)
    dat  <- aemet_follow_datos(meta)
    
    all_parts[[i]] <- as_tibble(dat)
    Sys.sleep(polite_sleep)
  }
  bind_rows(all_parts)
}

daily_raw <- download_daily_station(IDEMA, start_date, end_date)

# Save raw merged data
raw_name <- sprintf("retiro_%s_daily_raw_%s_%s.csv", IDEMA, start_date, end_date)
write_csv(daily_raw, raw_name)
cat("Saved raw:", raw_name, "\n")

# ----------------------------
# 4) Clean + enforce complete daily sequence + impute
# ----------------------------
# Expected fields often include: fecha, tmed, presMax, presMin
# If AEMET returns different names, run: print(names(daily_raw))

daily0 <- daily_raw |>
  transmute(
    fecha = as.Date(fecha),
    tmed = to_num(tmed),
    presMax = to_num(presMax),
    presMin = to_num(presMin)
  ) |>
  arrange(fecha) |>
  distinct(fecha, .keep_all = TRUE)

# Enforce complete daily sequence (guarantees 800 rows after join)
all_dates <- tibble(fecha = seq.Date(start_date, end_date, by = "day"))
daily_full <- all_dates |>
  left_join(daily0, by = "fecha") |>
  arrange(fecha)

cat("Rows in full date grid:", nrow(daily_full), "\n")      # should be 800
cat("Missing tmed:", sum(is.na(daily_full$tmed)), "\n")
cat("Missing presMax:", sum(is.na(daily_full$presMax)), "\n")
cat("Missing presMin:", sum(is.na(daily_full$presMin)), "\n")

# Impute (linear) to avoid losing rows and keep window consecutive
daily_full <- daily_full |>
  mutate(
    tmed    = impute_linear(fecha, tmed),
    presMax = impute_linear(fecha, presMax),
    presMin = impute_linear(fecha, presMin),
    pres_mean = (presMax + presMin) / 2
  )

# Final checks
stopifnot(nrow(daily_full) == 800)
stopifnot(sum(is.na(daily_full$tmed)) == 0)
stopifnot(sum(is.na(daily_full$pres_mean)) == 0)

cat("Final 800 rows OK. Date range:",
    as.character(min(daily_full$fecha)), "~", as.character(max(daily_full$fecha)), "\n")

# ----------------------------
# 5) Train/test split (reference paper: uniform 7:3)
# Your earlier script used chronological 560/240 (first 560 train, last 240 test).
# The reference paper states uniform 7:3. Choose ONE:
#   (A) Uniform 7:3 (recommended for strict reproduction)
#   (B) Chronological 560/240 (if you want time-ordered split)
# ----------------------------

SPLIT_MODE <- "uniform"   # "uniform" or "chronological"

set.seed(SEED_SPLIT)
n <- nrow(daily_full)
n_train <- 560

if (SPLIT_MODE == "uniform") {
  train_idx <- sort(sample.int(n, n_train))
  test_idx  <- setdiff(seq_len(n), train_idx)
  train <- daily_full[train_idx, ] |> arrange(fecha)
  test  <- daily_full[test_idx, ]  |> arrange(fecha)
} else if (SPLIT_MODE == "chronological") {
  train <- daily_full |> slice(1:n_train)
  test  <- daily_full |> slice((n_train + 1):n)
} else {
  stop("SPLIT_MODE must be 'uniform' or 'chronological'")
}

cat("Split mode:", SPLIT_MODE, "\n")
cat("Train rows:", nrow(train), " Test rows:", nrow(test), "\n")

# ----------------------------
# 6) Save datasets
# ----------------------------
tag <- sprintf("%s_%s_%s_%s", IDEMA, start_date, end_date, SPLIT_MODE)

clean_name <- sprintf("retiro_%s_daily_800_clean_%s.csv", IDEMA, tag)
train_name <- sprintf("retiro_%s_train_560_%s.csv", IDEMA, tag)
test_name  <- sprintf("retiro_%s_test_240_%s.csv", IDEMA, tag)

write_csv(daily_full, clean_name)
write_csv(train, train_name)
write_csv(test,  test_name)

cat("Saved:\n", clean_name, "\n", train_name, "\n", test_name, "\n", sep = "")
