# ============================================================
# GPR (RBF) for Madrid Retiro daily data (tmed, pres_mean)
# Outputs:
#   - outputs/Fig_2_1_GPR_presion.png
#   - outputs/Fig_2_2_GPR_temperatura.png
#   - outputs/Tabla_2_2_metricas_GPR.csv
#   - outputs/predicciones_GPR_madrid.csv
# ============================================================

# install.packages(c("readr","dplyr","lubridate"), dependencies = TRUE)

library(readr)
library(dplyr)
library(lubridate)

# ----------------------------
# 1) Paths (EDIT if needed)
# ----------------------------
data_dir <- "."   
out_dir  <- file.path(data_dir, "outputs")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

train_file <- file.path(data_dir, "retiro_3195_train_560_3195_2018-01-01_2020-03-10_uniform.csv")
test_file  <- file.path(data_dir, "retiro_3195_test_240_3195_2018-01-01_2020-03-10_uniform.csv")
clean_file <- file.path(data_dir, "retiro_3195_daily_800_clean_3195_2018-01-01_2020-03-10_uniform.csv") 

stopifnot(file.exists(train_file), file.exists(test_file))

train <- read_csv(train_file, show_col_types = FALSE) %>% mutate(fecha = as.Date(fecha))
test  <- read_csv(test_file,  show_col_types = FALSE) %>% mutate(fecha = as.Date(fecha))

# Optional: read full clean set for sanity checks
if (file.exists(clean_file)) {
  full <- read_csv(clean_file, show_col_types = FALSE) %>% mutate(fecha = as.Date(fecha))
  cat("Full rows:", nrow(full), "  Train:", nrow(train), "  Test:", nrow(test), "\n")
}

# ----------------------------
# 2) Core GP (RBF) implementation
# ----------------------------
rbf_K <- function(x1, x2, sigma_f, ell) {
  # squared exponential kernel: sigma_f^2 * exp(-0.5 * (d/ell)^2)
  d2 <- outer(x1, x2, function(a,b) (a-b)^2)
  (sigma_f^2) * exp(-0.5 * d2 / (ell^2))
}

gp_nll <- function(log_theta, x, y, jitter = 1e-8) {
  # log_theta = c(log_sigma_f, log_ell, log_sigma_n)
  sigma_f <- exp(log_theta[1])
  ell     <- exp(log_theta[2])
  sigma_n <- exp(log_theta[3])
  
  K <- rbf_K(x, x, sigma_f, ell)
  n <- length(y)
  Ky <- K + diag(sigma_n^2 + jitter, n)
  
  # Cholesky
  L <- tryCatch(chol(Ky), error = function(e) NULL)
  if (is.null(L)) return(1e50)
  
  # Solve alpha = Ky^{-1} y using chol
  alpha <- backsolve(L, forwardsolve(t(L), y))
  
  # log det
  logdet <- 2 * sum(log(diag(L)))
  
  # NLL
  0.5 * drop(t(y) %*% alpha) + 0.5 * logdet + 0.5 * n * log(2*pi)
}

gp_fit_rbf <- function(x_train, y_train, n_starts = 6, seed = 1234) {
  set.seed(seed)
  
  # heuristic init in standardized space
  ysd <- sd(y_train)
  xsd <- sd(x_train)
  
  # bounds (in log-space)
  lower <- c(log(1e-4), log(1e-4), log(1e-6))
  upper <- c(log(1e+3), log(1e+3), log(1e+1))
  
  # generate starts around heuristics
  starts <- matrix(NA_real_, nrow = n_starts, ncol = 3)
  for (i in 1:n_starts) {
    sigma_f0 <- max(ysd, 1e-3) * runif(1, 0.5, 2.0)
    ell0     <- max(xsd, 1e-3) * runif(1, 0.2, 2.5)
    sigma_n0 <- max(ysd, 1e-3) * runif(1, 0.02, 0.5)
    starts[i,] <- log(c(sigma_f0, ell0, sigma_n0))
  }
  
  best <- list(nll = Inf, log_theta = NULL, opt = NULL)
  
  for (i in 1:n_starts) {
    opt <- optim(
      par = starts[i,],
      fn  = gp_nll,
      x   = x_train,
      y   = y_train,
      method = "L-BFGS-B",
      lower = lower,
      upper = upper,
      control = list(maxit = 200)
    )
    if (is.finite(opt$value) && opt$value < best$nll) {
      best$nll <- opt$value
      best$log_theta <- opt$par
      best$opt <- opt
    }
  }
  
  theta <- exp(best$log_theta)
  names(theta) <- c("sigma_f","ell","sigma_n")
  list(theta = theta, nll = best$nll)
}

gp_predict_rbf <- function(x_train, y_train, x_star, theta, jitter = 1e-8) {
  sigma_f <- theta["sigma_f"]
  ell     <- theta["ell"]
  sigma_n <- theta["sigma_n"]
  
  K   <- rbf_K(x_train, x_train, sigma_f, ell)
  Ks  <- rbf_K(x_train, x_star,  sigma_f, ell)
  Kss <- rbf_K(x_star,  x_star,  sigma_f, ell)
  
  n <- length(y_train)
  Ky <- K + diag(sigma_n^2 + jitter, n)
  L  <- chol(Ky)
  
  # alpha = Ky^{-1} y
  alpha <- backsolve(L, forwardsolve(t(L), y_train))
  
  # mean f*
  mu_f <- drop(t(Ks) %*% alpha)
  
  # var f*: Kss - v^T v, where v = L^{-1} Ks
  v <- forwardsolve(t(L), Ks)
  var_f <- diag(Kss - t(v) %*% v)
  
  # predictive variance for y* includes noise
  var_y <- pmax(var_f + sigma_n^2, 0)
  
  list(mu = mu_f, var = var_y)
}

metrics_reg <- function(y, yhat) {
  mse <- mean((y - yhat)^2)
  mae <- mean(abs(y - yhat))
  r2  <- 1 - sum((y - yhat)^2) / sum((y - mean(y))^2)
  c(MSE = mse, MAE = mae, R2 = r2)
}

# ----------------------------
# 3) Run for one variable
# ----------------------------
run_one <- function(train, test, ycol, fig_file, ylab) {
  
  # x = day index since window start (in days)
  min_date <- min(c(train$fecha, test$fecha), na.rm = TRUE)
  x_tr0 <- as.numeric(train$fecha - min_date)
  x_te0 <- as.numeric(test$fecha  - min_date)
  
  y_tr0 <- train[[ycol]]
  y_te0 <- test[[ycol]]
  
  stopifnot(all(is.finite(x_tr0)), all(is.finite(x_te0)))
  stopifnot(all(is.finite(y_tr0)), all(is.finite(y_te0)))
  
  # standardize using TRAIN only
  x_mean <- mean(x_tr0); x_sd <- sd(x_tr0)
  y_mean <- mean(y_tr0); y_sd <- sd(y_tr0)
  
  x_tr <- (x_tr0 - x_mean) / x_sd
  x_te <- (x_te0 - x_mean) / x_sd
  y_tr <- (y_tr0 - y_mean) / y_sd
  
  # fit GP
  fit <- gp_fit_rbf(x_tr, y_tr, n_starts = 6, seed = 1234)
  theta <- fit$theta
  cat("\n[", ycol, "] theta (std-space):",
      "sigma_f =", signif(theta["sigma_f"],6),
      " ell =", signif(theta["ell"],6),
      " sigma_n =", signif(theta["sigma_n"],6),
      " nll =", signif(fit$nll,6), "\n", sep="")
  
  # predict on train & test
  pred_tr <- gp_predict_rbf(x_tr, y_tr, x_tr, theta)
  pred_te <- gp_predict_rbf(x_tr, y_tr, x_te, theta)
  
  # back to original y scale
  yhat_tr <- pred_tr$mu * y_sd + y_mean
  yhat_te <- pred_te$mu * y_sd + y_mean
  
  sd_tr <- sqrt(pred_tr$var) * y_sd
  sd_te <- sqrt(pred_te$var) * y_sd
  
  lo_tr <- yhat_tr - 1.96 * sd_tr
  up_tr <- yhat_tr + 1.96 * sd_tr
  lo_te <- yhat_te - 1.96 * sd_te
  up_te <- yhat_te + 1.96 * sd_te
  
  # metrics
  m_tr <- metrics_reg(y_tr0, yhat_tr)
  m_te <- metrics_reg(y_te0, yhat_te)
  
  # build prediction frames for export + plotting
  df_tr <- tibble(
    set = "train",
    fecha = train$fecha,
    y = y_tr0,
    yhat = yhat_tr,
    lower = lo_tr,
    upper = up_tr
  ) %>% arrange(fecha)
  
  df_te <- tibble(
    set = "test",
    fecha = test$fecha,
    y = y_te0,
    yhat = yhat_te,
    lower = lo_te,
    upper = up_te
  ) %>% arrange(fecha)
  
  # ---- Plot: two panels (train left, test right) ----
  png(fig_file, width = 2200, height = 900, res = 200)
  par(mfrow = c(1,2), mar = c(4.5,4.5,3,1))
  
  plot_panel <- function(df, main_title) {
    # band first
    plot(df$fecha, df$y,
         xlab = "Fecha", ylab = ylab,
         main = main_title, pch = 16, cex = 0.6)
    
    polygon(
      x = c(df$fecha, rev(df$fecha)),
      y = c(df$lower, rev(df$upper)),
      border = NA,
      col = grDevices::adjustcolor("gray70", alpha.f = 0.4)
    )
    
    lines(df$fecha, df$yhat, lwd = 2)
    points(df$fecha, df$y, pch = 16, cex = 0.6)
    legend("topleft",
           legend = c("Observado","Predicción (media)","PI 95%"),
           lwd = c(NA,2,NA), pch = c(16,NA,15),
           pt.cex = c(0.8,NA,1.2),
           bty = "n")
  }
  
  plot_panel(df_tr, "Entrenamiento")
  plot_panel(df_te, "Prueba")
  dev.off()
  
  list(
    preds = bind_rows(df_tr, df_te),
    metrics_train = m_tr,
    metrics_test  = m_te
  )
}

# ----------------------------
# 4) Run both variables + export
# ----------------------------
res_pres <- run_one(
  train, test,
  ycol = "pres_mean",
  fig_file = file.path(out_dir, "Fig_2_1_GPR_presion.png"),
  ylab = "Presión media diaria (hPa)"
)

res_tmed <- run_one(
  train, test,
  ycol = "tmed",
  fig_file = file.path(out_dir, "Fig_2_2_GPR_temperatura.png"),
  ylab = "Temperatura media diaria (°C)"
)

# ---- Metrics table (Tabla 2.2) ----
tabla <- tibble(
  variable = c("pres_mean", "tmed"),
  MSE_train = c(res_pres$metrics_train["MSE"], res_tmed$metrics_train["MSE"]),
  MAE_train = c(res_pres$metrics_train["MAE"], res_tmed$metrics_train["MAE"]),
  R2_train  = c(res_pres$metrics_train["R2"],  res_tmed$metrics_train["R2"]),
  MSE_test  = c(res_pres$metrics_test["MSE"],  res_tmed$metrics_test["MSE"]),
  MAE_test  = c(res_pres$metrics_test["MAE"],  res_tmed$metrics_test["MAE"]),
  R2_test   = c(res_pres$metrics_test["R2"],   res_tmed$metrics_test["R2"])
)

write_csv(tabla, file.path(out_dir, "Tabla_2_2_metricas_GPR.csv"))
print(tabla)

# ---- Export predictions (for reproducibility / appendix) ----
preds_all <- bind_rows(
  res_pres$preds %>% mutate(variable = "pres_mean"),
  res_tmed$preds %>% mutate(variable = "tmed")
) %>% select(variable, set, fecha, y, yhat, lower, upper)

write_csv(preds_all, file.path(out_dir, "predicciones_GPR_madrid.csv"))

cat("\nDone. Outputs written to:", out_dir, "\n")
