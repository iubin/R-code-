# install.packages(c("dplyr","readr","DiceKriging","akima"), dependencies = TRUE)
library(dplyr)
library(readr)
library(DiceKriging)

out_dir <- "outputs"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
set.seed(20260115)

gen_batch <- function(t_seq) {
  w <- runif(length(t_seq), 0, 3)
  y  <- sin(t_seq^2) - t_seq + 0.2 * w
  x1 <- t_seq^3 + exp(2 * t_seq) + w
  x2 <- tan(t_seq^3) + 0.2 * w
  data.frame(t=t_seq, x1=x1, x2=x2, y=y)
}

gen_dataset <- function(n_t, n_batches) {
  t_seq <- seq(-3, 3, length.out = n_t)
  bind_rows(lapply(seq_len(n_batches), function(b) {
    gen_batch(t_seq) %>% mutate(batch=b)
  }))
}

train <- gen_dataset(70, 20)  # 1400
test  <- gen_dataset(30, 20)  # 600
stopifnot(nrow(train)==1400, nrow(test)==600)

write_csv(train, file.path(out_dir, "sim_data_train.csv"))
write_csv(test,  file.path(out_dir, "sim_data_test.csv"))

Xtr0 <- as.matrix(train[, c("t","x1","x2")])
Xte0 <- as.matrix(test[,  c("t","x1","x2")])
ytr0 <- train$y
yte0 <- test$y

# standardize using train statistics
x_mean <- colMeans(Xtr0); x_sd <- apply(Xtr0, 2, sd)
Xtr <- scale(Xtr0, center=x_mean, scale=x_sd)
Xte <- scale(Xte0, center=x_mean, scale=x_sd)

y_mean <- mean(ytr0); y_sd <- sd(ytr0)
ytr <- (ytr0 - y_mean) / y_sd

# GPR with RBF kernel
fit <- km(
  design = Xtr,
  response = ytr,
  covtype = "gauss",
  nugget.estim = FALSE,
  nugget = 1e-2,   # 你可以从 1e-3 ~ 1e-1 试，直到训练MSE不再接近0
  control = list(trace = FALSE)
)


pred_tr <- predict(fit, newdata = Xtr, type="UK", se.compute=TRUE)
pred_te <- predict(fit, newdata = Xte, type="UK", se.compute=TRUE)

yhat_tr <- pred_tr$mean * y_sd + y_mean
yhat_te <- pred_te$mean * y_sd + y_mean

metrics_reg <- function(y, yhat) {
  mse <- mean((y-yhat)^2)
  mae <- mean(abs(y-yhat))
  r2  <- 1 - sum((y-yhat)^2) / sum((y-mean(y))^2)
  c(MSE=mse, MAE=mae, R2=r2)
}

m_tr <- metrics_reg(ytr0, yhat_tr)
m_te <- metrics_reg(yte0, yhat_te)

tabla <- tibble(
  Modelo="GPR (RBF)",
  MSE_train=m_tr["MSE"], MAE_train=m_tr["MAE"], R2_train=m_tr["R2"],
  MSE_test =m_te["MSE"], MAE_test =m_te["MAE"], R2_test =m_te["R2"]
)
write_csv(tabla, file.path(out_dir, "Tabla_2_3_GPR_sim_loss.csv"))
print(tabla)

# Representative figure: y vs t, train/test two panels
plot_y_t <- function(df, figfile, title_main) {
  agg <- df %>% group_by(t) %>%
    summarise(y_mean=mean(y), yhat_mean=mean(yhat), .groups="drop") %>% arrange(t)
  
  png(figfile, width=2200, height=900, res=200)
  par(mfrow=c(1,2), mar=c(4.5,4.5,3,1))
  
  plot(df$t, df$y, pch=16, cex=0.5, xlab="t", ylab="y", main=paste(title_main, "(train)"))
  agg <- df %>%
    group_by(t) %>%
    summarise(y_mean=mean(y), yhat_mean=mean(yhat), .groups="drop") %>%
    arrange(t)
  
  lines(agg$t, agg$yhat_mean, lwd=2)
  
  df2 <- test %>% mutate(yhat=yhat_te)
  agg2 <- df2 %>% group_by(t) %>% summarise(y_mean=mean(y), yhat_mean=mean(yhat), .groups="drop") %>% arrange(t)
  plot(df2$t, df2$y, pch=16, cex=0.5, xlab="t", ylab="y", main=paste(title_main, "(test)"))
  lines(agg2$t, agg2$yhat_mean, lwd=2)
  
  dev.off()
}

train2 <- train %>% mutate(yhat=yhat_tr)
test2  <- test  %>% mutate(yhat=yhat_te)
plot_y_t(train2, file.path(out_dir, "Fig_2_3_GPR_sim_y_t_train_test.png"),
         "Figura 2.3. GPR en datos sintéticos: y vs t")
