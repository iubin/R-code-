# ============================================================
# OPSD Spain load -> 800 points -> GPR(RBF) -> plots + metrics
# ============================================================

pkgs <- c("data.table","dplyr","tibble","lubridate","readr","kernlab","ggplot2","curl")
to_install <- pkgs[!pkgs %in% rownames(installed.packages())]
if (length(to_install) > 0) install.packages(to_install, dependencies = TRUE)

library(data.table)
library(dplyr)
library(tibble)
library(lubridate)
library(readr)
library(kernlab)
library(ggplot2)
library(curl)

# -----------------------------
# 1) Download with retry
# -----------------------------
download_with_retry <- function(url, dest, max_tries = 10) {
  for (i in seq_len(max_tries)) {
    ok <- tryCatch({
      curl::curl_download(url, destfile = dest, quiet = FALSE, mode = "wb")
      TRUE
    }, error = function(e) {
      message("Download error: ", conditionMessage(e))
      FALSE
    })
    
    if (ok && file.exists(dest) && file.info(dest)$size > 1024) return(invisible(TRUE))
    
    wait_s <- min(2^(i - 1), 120) + runif(1, 0, 1)
    message(sprintf("Retrying download in %.1f s (%d/%d)...", wait_s, i, max_tries))
    Sys.sleep(wait_s)
  }
  stop("Download failed after retries: ", url)
}

# -----------------------------
# 2) Source: OPSD time_series (60min, singleindex)
#    Column naming pattern includes ES_load_actual_entsoe_transparency
# -----------------------------
URL_OPSD_60MIN <- "https://data.open-power-system-data.org/time_series/2020-10-06/time_series_60min_singleindex.csv"
LOCAL_CSV <- "opds_time_series_60min_singleindex_2020-10-06.csv"

if (!file.exists(LOCAL_CSV)) {
  download_with_retry(URL_OPSD_60MIN, LOCAL_CSV, max_tries = 10)
}

# -----------------------------
# 3) Read only needed columns (fast + low RAM)
# -----------------------------
cols_need <- c("cet_cest_timestamp", "ES_load_actual_entsoe_transparency")
dt <- data.table::fread(LOCAL_CSV, select = cols_need, showProgress = TRUE)

df <- as_tibble(dt) |>
  transmute(
    datetime = as.POSIXct(cet_cest_timestamp, format = "%Y-%m-%dT%H:%M:%S%z", tz = "Europe/Madrid"),
    load_mw  = as.numeric(ES_load_actual_entsoe_transparency)
  ) |>
  filter(!is.na(datetime), !is.na(load_mw)) |>
  arrange(datetime)

# ============================================================
# 4) Choose mode
# ============================================================
MODE <- "hourly800"   # <- 改成 "daily800" 就生成 800 天（日均）

if (MODE == "hourly800") {
  # 选一个稳定年份窗口：2019-01-01 起取连续 800 小时
  start_dt <- as.POSIXct("2019-01-01 00:00:00", tz = "Europe/Madrid")
  df800 <- df |>
    filter(datetime >= start_dt) |>
    slice_head(n = 800)
  
  if (nrow(df800) < 800) stop("Not enough hourly points after start_dt. Change start_dt.")
  
  data800 <- df800 |>
    mutate(x = row_number(), y = load_mw) |>
    select(x, datetime, y)
  
} else if (MODE == "daily800") {
  # 从 2018-01-01 起聚合成日均，然后取 800 天
  start_date <- as.Date("2018-01-01")
  daily <- df |>
    mutate(date = as.Date(datetime)) |>
    group_by(date) |>
    summarise(y = mean(load_mw, na.rm = TRUE), .groups = "drop") |>
    filter(!is.na(y)) |>
    arrange(date) |>
    filter(date >= start_date)
  
  data800 <- daily |>
    slice_head(n = 800) |>
    mutate(x = row_number(), datetime = as.POSIXct(date, tz = "Europe/Madrid")) |>
    select(x, datetime, y)
  
  if (nrow(data800) < 800) stop("Not enough daily points after start_date. Change start_date.")
  
} else {
  stop("MODE must be 'hourly800' or 'daily800'")
}

# Save 800 clean
write_csv(data800, paste0("spain_load_", MODE, "_800_clean.csv"))

# ============================================================
# 5) Split 7:3 uniform (560/240)
# ============================================================
set.seed(123)
n <- nrow(data800)
n_train <- floor(0.7 * n)

train_idx <- sort(sample.int(n, n_train))
test_idx  <- setdiff(seq_len(n), train_idx)

train <- data800[train_idx, ] |> arrange(x)
test  <- data800[test_idx,  ] |> arrange(x)

write_csv(train, paste0("spain_load_", MODE, "_train_560.csv"))
write_csv(test,  paste0("spain_load_", MODE, "_test_240.csv"))

# ============================================================
# 6) GPR (RBF) + metrics
# ============================================================
mse <- function(a, b) mean((a - b)^2)
mae <- function(a, b) mean(abs(a - b))
r2  <- function(y, yhat) 1 - sum((y - yhat)^2) / sum((y - mean(y))^2)

# Standardize x,y for stability
x_train <- scale(matrix(train$x, ncol = 1))
y_train <- scale(train$y)

x_test  <- scale(matrix(test$x, ncol = 1),
                 center = attr(x_train, "scaled:center"),
                 scale  = attr(x_train, "scaled:scale"))

y_center <- attr(y_train, "scaled:center")
y_scale  <- attr(y_train, "scaled:scale")

fit <- gausspr(x = x_train, y = as.numeric(y_train),
               kernel = "rbfdot", kpar = "automatic", var = 1e-3)

pred_train_z <- predict(fit, x_train)
pred_test_z  <- predict(fit, x_test)

pred_train <- as.numeric(pred_train_z) * y_scale + y_center
pred_test  <- as.numeric(pred_test_z)  * y_scale + y_center

tabla <- tibble(
  Modelo   = "GPR (RBF)",
  MSE_train = mse(train$y, pred_train),
  MAE_train = mae(train$y, pred_train),
  R2_train  = r2(train$y, pred_train),
  MSE_test  = mse(test$y,  pred_test),
  MAE_test  = mae(test$y,  pred_test),
  R2_test   = r2(test$y,   pred_test)
)

print(tabla)
write_csv(tabla, paste0("spain_load_", MODE, "_metrics.csv"))

# ============================================================
# 7) Plots (train/test)
# ============================================================
train_plot <- train |> mutate(yhat = pred_train) |> arrange(x)
test_plot  <- test  |> mutate(yhat = pred_test)  |> arrange(x)

p_train <- ggplot(train_plot, aes(x = x)) +
  geom_point(aes(y = y), size = 1) +
  geom_line(aes(y = yhat), linewidth = 0.8) +
  labs(title = paste0("GPR (RBF) - Spain load - Train (", MODE, ")"),
       x = "x", y = "Load (MW)") +
  theme_bw()

p_test <- ggplot(test_plot, aes(x = x)) +
  geom_point(aes(y = y), size = 1) +
  geom_line(aes(y = yhat), linewidth = 0.8) +
  labs(title = paste0("GPR (RBF) - Spain load - Test (", MODE, ")"),
       x = "x", y = "Load (MW)") +
  theme_bw()

ggsave(paste0("Fig_spain_load_", MODE, "_GPR_train.png"), p_train, width = 7, height = 4, dpi = 150)
ggsave(paste0("Fig_spain_load_", MODE, "_GPR_test.png"),  p_test,  width = 7, height = 4, dpi = 150)

message("DONE. Outputs:\n",
        " - spain_load_", MODE, "_800_clean.csv\n",
        " - spain_load_", MODE, "_train_560.csv / _test_240.csv\n",
        " - Fig_spain_load_", MODE, "_GPR_train.png / _GPR_test.png\n",
        " - spain_load_", MODE, "_metrics.csv\n")
