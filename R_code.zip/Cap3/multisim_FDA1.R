############################################################
# 3.5.2.4 Aplicación 3: datos multivariantes simulados (FDA baseline)
# Método: Suavizado local (local linear) sobre t con kernel biweight
#         w(u) = (1 - u^2)^2 I(|u|<=1), span = 0.25
#
# Inputs:
#   sim_data_train.csv  (cols: t, y, [x1, x2, batch...])
#   sim_data_test.csv
#
# Outputs:
#   pred_FDA_sim_train.csv
#   pred_FDA_sim_test.csv
#   Tabla_3_4_metricas_FDA_sim.csv
#   Fig_3_13_FDA_sim_y_t_train.png
#   Fig_3_14_FDA_sim_y_t_test.png
############################################################

# ---- packages ----
if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
library(ggplot2)

# ---- config ----
TRAIN_FILE <- "sim_data_train.csv"
TEST_FILE  <- "sim_data_test.csv"

SPAN    <- 0.25     # 25% (según el original)
NGRID_T <- 400      # densidad para línea/banda en t

# ---- utilities ----
stop_if_missing <- function(path) {
  if (!file.exists(path)) stop(paste0("No existe el archivo: ", path))
}

mse <- function(y, yhat) mean((y - yhat)^2, na.rm = TRUE)
mae <- function(y, yhat) mean(abs(y - yhat), na.rm = TRUE)
r2  <- function(y, yhat) {
  sse <- sum((y - yhat)^2, na.rm = TRUE)
  sst <- sum((y - mean(y, na.rm = TRUE))^2, na.rm = TRUE)
  1 - sse / sst
}

# ---- kernel biweight/quartic: (1-u^2)^2, support |u|<=1 ----
k_biweight <- function(u) {
  out <- (1 - u^2)^2
  out[abs(u) > 1] <- 0
  pmax(out, 0)
}

# ---- aggregate by t (mean) to avoid repeated t singularity ----
aggregate_by_t <- function(df) {
  agg_mean <- aggregate(y ~ t, df, mean)
  agg_sd   <- aggregate(y ~ t, df, sd)
  agg_n    <- aggregate(y ~ t, df, length)
  names(agg_mean)[2] <- "y_mean"
  names(agg_sd)[2]   <- "y_sd"
  names(agg_n)[2]    <- "n"
  out <- merge(merge(agg_mean, agg_sd, by = "t", all = TRUE),
               agg_n, by = "t", all = TRUE)
  out$y_sd[is.na(out$y_sd)] <- 0
  out
}

# ---- local linear smoother at a point x0 (trained on unique t) ----
local_linear_1d_point <- function(x, y, x0, span = 0.25, eps = 1e-12) {
  n <- length(x)
  k <- max(5, ceiling(span * n))     # neighborhood size
  d <- abs(x - x0)
  idx <- order(d)[seq_len(k)]
  h <- max(d[idx]) + eps             # bandwidth = farthest distance in neighborhood
  
  u <- d[idx] / h
  w <- k_biweight(u)
  
  # centered design: [1, (x-x0)]
  xc <- x[idx] - x0
  X  <- cbind(1, xc)
  ysub <- y[idx]
  
  # weighted normal equations
  XtW  <- t(X * w)
  XtWX <- XtW %*% X
  XtWy <- XtW %*% ysub
  
  beta <- tryCatch(solve(XtWX, XtWy), error = function(e) NULL)
  
  if (is.null(beta) || any(!is.finite(beta)) || sum(w) <= 0) {
    # fallback: weighted mean
    yhat <- sum(w * ysub) / max(sum(w), eps)
    sdw  <- sqrt(sum(w * (ysub - yhat)^2) / max(sum(w), eps))
    return(list(yhat = yhat, sd = sdw))
  }
  
  yhat <- as.numeric(beta[1])        # prediction at x0
  yfit <- as.numeric(X %*% beta)
  sdw  <- sqrt(sum(w * (ysub - yfit)^2) / max(sum(w), eps))
  list(yhat = yhat, sd = sdw)
}

local_linear_1d_vec <- function(x, y, x0_vec, span = 0.25) {
  yhat <- numeric(length(x0_vec))
  sdv  <- numeric(length(x0_vec))
  for (i in seq_along(x0_vec)) {
    tmp <- local_linear_1d_point(x, y, x0_vec[i], span = span)
    yhat[i] <- tmp$yhat
    sdv[i]  <- tmp$sd
  }
  data.frame(x0 = x0_vec, yhat = yhat, sd = sdv)
}

# =========================
# 1) load data
# =========================
stop_if_missing(TRAIN_FILE)
stop_if_missing(TEST_FILE)

df_tr <- read.csv(TRAIN_FILE)
df_te <- read.csv(TEST_FILE)

if (!all(c("t","y") %in% names(df_tr))) stop("Train debe contener columnas t,y")
if (!all(c("t","y") %in% names(df_te))) stop("Test debe contener columnas t,y")

# =========================
# 2) train smoother on unique t (from TRAIN only)
# =========================
tr_agg <- aggregate_by_t(df_tr[, c("t","y")])  # unique t with mean y

# dense grid for drawing line/band
t_grid <- seq(min(tr_agg$t), max(tr_agg$t), length.out = NGRID_T)
fit_grid <- local_linear_1d_vec(tr_agg$t, tr_agg$y_mean, t_grid, span = SPAN)
fit_grid$lwr <- fit_grid$yhat - 1.96 * fit_grid$sd
fit_grid$upr <- fit_grid$yhat + 1.96 * fit_grid$sd

# predictions for train/test points (IMPORTANT: use TRAIN smoother for BOTH)
fit_tr_pts <- local_linear_1d_vec(tr_agg$t, tr_agg$y_mean, df_tr$t, span = SPAN)
fit_te_pts <- local_linear_1d_vec(tr_agg$t, tr_agg$y_mean, df_te$t, span = SPAN)

pred_tr <- cbind(df_tr,
                 yhat = fit_tr_pts$yhat,
                 lwr  = fit_tr_pts$yhat - 1.96 * fit_tr_pts$sd,
                 upr  = fit_tr_pts$yhat + 1.96 * fit_tr_pts$sd)

pred_te <- cbind(df_te,
                 yhat = fit_te_pts$yhat,
                 lwr  = fit_te_pts$yhat - 1.96 * fit_te_pts$sd,
                 upr  = fit_te_pts$yhat + 1.96 * fit_te_pts$sd)

# =========================
# 3) metrics + export
# =========================
tabla <- data.frame(
  Modelo   = "FDA (suavizado local 1D sobre t; kernel biweight; span=0.25)",
  MSE_train = mse(pred_tr$y, pred_tr$yhat),
  MAE_train = mae(pred_tr$y, pred_tr$yhat),
  R2_train  = r2(pred_tr$y, pred_tr$yhat),
  MSE_test  = mse(pred_te$y, pred_te$yhat),
  MAE_test  = mae(pred_te$y, pred_te$yhat),
  R2_test   = r2(pred_te$y, pred_te$yhat)
)

write.csv(pred_tr, "pred_FDA_sim_train.csv", row.names = FALSE)
write.csv(pred_te, "pred_FDA_sim_test.csv", row.names = FALSE)
write.csv(tabla,  "Tabla_3_4_metricas_FDA_sim.csv", row.names = FALSE)

# =========================
# 4) plots (match original: prediction vs true)
# =========================
# build plot data (points)
plot_tr <- data.frame(t = df_tr$t,
                      value = c(pred_tr$yhat, pred_tr$y),
                      type  = rep(c("prediction","true value"), each = nrow(df_tr)))
plot_te <- data.frame(t = df_te$t,
                      value = c(pred_te$yhat, pred_te$y),
                      type  = rep(c("prediction","true value"), each = nrow(df_te)))

# theme
base_theme <- theme_bw(base_size = 14) +
  theme(plot.title = element_text(face = "bold"),
        axis.title = element_text(face = "bold"),
        legend.title = element_blank(),
        legend.position = c(0.88, 0.87))

# TRAIN figure
p_tr <- ggplot() +
  geom_point(data = plot_tr, aes(x = t, y = value, color = type),
             size = 1.2, alpha = 0.75) +
  # optional smooth line + 95% band from TRAIN smoother
  geom_ribbon(data = fit_grid, aes(x = x0, ymin = lwr, ymax = upr),
              inherit.aes = FALSE, alpha = 0.15) +
  geom_line(data = fit_grid, aes(x = x0, y = yhat),
            inherit.aes = FALSE, linewidth = 0.9) +
  labs(title = "y(train) about time", x = "time", y = "y") +
  base_theme

# TEST figure
p_te <- ggplot() +
  geom_point(data = plot_te, aes(x = t, y = value, color = type),
             size = 1.2, alpha = 0.75) +
  geom_ribbon(data = fit_grid, aes(x = x0, ymin = lwr, ymax = upr),
              inherit.aes = FALSE, alpha = 0.15) +
  geom_line(data = fit_grid, aes(x = x0, y = yhat),
            inherit.aes = FALSE, linewidth = 0.9) +
  labs(title = "y(test) about time", x = "time", y = "y") +
  base_theme

ggsave("Fig_3_13_FDA_sim_y_t_train.png", p_tr, width = 12, height = 6, dpi = 160)
ggsave("Fig_3_14_FDA_sim_y_t_test.png",  p_te, width = 12, height = 6, dpi = 160)

print(tabla)
cat("\nOK. Files generated in:", getwd(), "\n")
