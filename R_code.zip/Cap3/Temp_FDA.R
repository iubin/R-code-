############################################################
# Capítulo 3 - 3.5.2 (Ejemplo 1)  FDA: tmed (Madrid Retiro)
# Fourier basis + penalización D2 + selección lambda por GCV
# Figura: train/test (dos paneles) SIN gridExtra
############################################################

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(lubridate)
  library(ggplot2)
  library(fda)
})

# ---- 0) Files (ajusta si tu carpeta es distinta) ----
FILE_ALL   <- "retiro_3195_daily_800_clean_3195_2018-01-01_2020-03-10_uniform.csv"
FILE_TRAIN <- "retiro_3195_train_560_3195_2018-01-01_2020-03-10_uniform.csv"
FILE_TEST  <- "retiro_3195_test_240_3195_2018-01-01_2020-03-10_uniform.csv"

# ---- 1) Load data ----
all_df <- read_csv(FILE_ALL, show_col_types = FALSE) %>%
  mutate(fecha = as.Date(fecha)) %>%
  arrange(fecha) %>%
  mutate(t_idx = row_number())  # 1..800

train_df <- read_csv(FILE_TRAIN, show_col_types = FALSE) %>%
  mutate(fecha = as.Date(fecha)) %>%
  left_join(all_df %>% select(fecha, t_idx), by = "fecha")

test_df <- read_csv(FILE_TEST, show_col_types = FALSE) %>%
  mutate(fecha = as.Date(fecha)) %>%
  left_join(all_df %>% select(fecha, t_idx), by = "fecha")

stopifnot(all(!is.na(train_df$t_idx)), all(!is.na(test_df$t_idx)))

# ---- 2) Variable: tmed ----
y_name  <- "tmed"
y_label <- "Temperatura media diaria (°C)"

t_train <- train_df$t_idx
y_train <- train_df[[y_name]]

t_test  <- test_df$t_idx
y_test  <- test_df[[y_name]]

t_grid    <- all_df$t_idx
date_grid <- all_df$fecha

# ---- 3) Metrics ----
mse <- function(y, yhat) mean((y - yhat)^2, na.rm = TRUE)
mae <- function(y, yhat) mean(abs(y - yhat), na.rm = TRUE)
r2  <- function(y, yhat) {
  sse <- sum((y - yhat)^2, na.rm = TRUE)
  sst <- sum((y - mean(y, na.rm = TRUE))^2, na.rm = TRUE)
  1 - sse/sst
}

# ---- 4) Lambda selection by GCV ----
select_lambda_gcv <- function(argvals, y, basisobj, Lfd = 2,
                              log10_lambda_grid = seq(-6, 2, by = 0.25)) {
  gcv_vals <- numeric(length(log10_lambda_grid))
  
  for (i in seq_along(log10_lambda_grid)) {
    lam <- 10^log10_lambda_grid[i]
    fdpar <- fdPar(basisobj, Lfdobj = int2Lfd(Lfd), lambda = lam)
    sb <- smooth.basis(argvals = argvals, y = y, fdParobj = fdpar)
    gcv_vals[i] <- as.numeric(sb$gcv)
  }
  
  i_best <- which.min(gcv_vals)
  list(lambda = 10^log10_lambda_grid[i_best],
       gcv_table = data.frame(log10_lambda = log10_lambda_grid, gcv = gcv_vals))
}

# ---- 5) Fourier basis ----
rangeval <- c(min(t_grid), max(t_grid))  # 1..800
period_annual <- 365.25
nbasis <- 25

basis_fourier <- create.fourier.basis(rangeval = rangeval,
                                      nbasis = nbasis,
                                      period = period_annual)

# ---- 6) Fit FDA on TRAIN ----
sel <- select_lambda_gcv(argvals = t_train, y = y_train,
                         basisobj = basis_fourier, Lfd = 2,
                         log10_lambda_grid = seq(-6, 2, by = 0.25))

lambda_best <- sel$lambda
cat("Selected lambda by GCV =", format(lambda_best, scientific = TRUE), "\n")

fdpar_best <- fdPar(basis_fourier, Lfdobj = int2Lfd(2), lambda = lambda_best)
fit_train  <- smooth.basis(argvals = t_train, y = y_train, fdParobj = fdpar_best)
fd_hat <- fit_train$fd

# ---- 7) Predictions ----
yhat_train <- as.numeric(eval.fd(t_train, fd_hat))
yhat_test  <- as.numeric(eval.fd(t_test,  fd_hat))
yhat_grid  <- as.numeric(eval.fd(t_grid,  fd_hat))

# Approx 95% band from TRAIN residual SD
sigma_hat <- sd(y_train - yhat_train, na.rm = TRUE)
upper_grid <- yhat_grid + 1.96 * sigma_hat
lower_grid <- yhat_grid - 1.96 * sigma_hat

# ---- 8) Metrics table ----
metrics <- tibble::tibble(
  Modelo = paste0("FDA (Fourier + D2, nbasis=", nbasis, ")"),
  lambda = lambda_best,
  MSE_train = mse(y_train, yhat_train),
  MAE_train = mae(y_train, yhat_train),
  R2_train  = r2(y_train,  yhat_train),
  MSE_test  = mse(y_test,  yhat_test),
  MAE_test  = mae(y_test,  yhat_test),
  R2_test   = r2(y_test,   yhat_test)
)

print(metrics)
write_csv(metrics, "Tabla_3_1_metricas_FDA_tmed.csv")

# ---- 9) Build ggplots (two separate plots) ----
df_grid <- data.frame(
  fecha = date_grid,
  yhat  = yhat_grid,
  lo    = lower_grid,
  hi    = upper_grid
)

df_train_plot <- train_df %>% transmute(fecha, y = .data[[y_name]])
df_test_plot  <- test_df  %>% transmute(fecha, y = .data[[y_name]])

p_train <- ggplot() +
  geom_ribbon(data = df_grid, aes(x = fecha, ymin = lo, ymax = hi), alpha = 0.25) +
  geom_line(data = df_grid, aes(x = fecha, y = yhat), linewidth = 1) +
  geom_point(data = df_train_plot, aes(x = fecha, y = y), size = 1.3) +
  labs(title = "Entrenamiento", x = "Fecha", y = y_label) +
  theme_bw(base_size = 14)

p_test <- ggplot() +
  geom_ribbon(data = df_grid, aes(x = fecha, ymin = lo, ymax = hi), alpha = 0.25) +
  geom_line(data = df_grid, aes(x = fecha, y = yhat), linewidth = 1) +
  geom_point(data = df_test_plot, aes(x = fecha, y = y), size = 1.3) +
  labs(title = "Prueba", x = "Fecha", y = y_label) +
  theme_bw(base_size = 14)

# 1) 单独保存训练/测试两张图
ggsave("Fig_3_1a_FDA_tmed_train.png", p_train, width = 6.5, height = 4.5, dpi = 180)
ggsave("Fig_3_1b_FDA_tmed_test.png",  p_test,  width = 6.5, height = 4.5, dpi = 180)



