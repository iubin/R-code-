############################################################
# FULL FDA SCRIPT for Chapter 3.5
# - 3.5.2.1 tmed (daily): Fourier + D2 + GCV
# - 3.5.2.2 pres_mean (daily): Fourier + D2 + GCV + local residual band
# - 3.5.2.3 Spain load (hourly 800): Penalized LS (basis + D2) + GCV
# Outputs (by default into OUT_DIR):
#   Tabla_3_1_metricas_FDA_tmed.csv, Fig_3_1a/b_FDA_tmed_*.png
#   Tabla_3_2_metricas_FDA_pres_mean.csv, Fig_3_2a/b_FDA_pres_mean_*.png
#   Tabla_3_3_metricas_FDA_spain_load.csv, Fig_3_3_*_spain_load_*.png, GCV_3_3_grid_spain_load.csv
############################################################

suppressPackageStartupMessages({
  if (!requireNamespace("fda", quietly = TRUE)) install.packages("fda")
  if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
  if (!requireNamespace("readr", quietly = TRUE)) install.packages("readr")
  if (!requireNamespace("dplyr", quietly = TRUE)) install.packages("dplyr")
  if (!requireNamespace("lubridate", quietly = TRUE)) install.packages("lubridate")
  library(fda)
  library(ggplot2)
  library(readr)
  library(dplyr)
  library(lubridate)
})

# =========================
# 0) Global config
# =========================
DATA_DIR <- "."     # put your CSV files here
OUT_DIR  <- "."     # outputs saved here

# ---- Daily files (tmed/pres) ----
FILE_ALL_DAILY   <- "retiro_3195_daily_800_clean_3195_2018-01-01_2020-03-10_uniform.csv"
FILE_TRAIN_DAILY <- "retiro_3195_train_560_3195_2018-01-01_2020-03-10_uniform.csv"
FILE_TEST_DAILY  <- "retiro_3195_test_240_3195_2018-01-01_2020-03-10_uniform.csv"

# ---- Hourly load file ----
FILE_SPAIN_LOAD  <- "spain_load_hourly800_800_clean.csv"

# =========================
# 1) Helpers
# =========================
path_in <- function(fname) file.path(DATA_DIR, fname)
path_out <- function(fname) file.path(OUT_DIR, fname)

mse <- function(y, yhat) mean((y - yhat)^2, na.rm = TRUE)
mae <- function(y, yhat) mean(abs(y - yhat), na.rm = TRUE)
r2  <- function(y, yhat) {
  sse <- sum((y - yhat)^2, na.rm = TRUE)
  sst <- sum((y - mean(y, na.rm = TRUE))^2, na.rm = TRUE)
  1 - sse/sst
}

lin_interp <- function(x) {
  if (!anyNA(x)) return(x)
  idx <- seq_along(x)
  ok <- !is.na(x)
  if (sum(ok) < 2) return(x)
  x[!ok] <- approx(idx[ok], x[ok], xout = idx[!ok], method = "linear", rule = 2)$y
  x
}

select_lambda_gcv_smoothbasis <- function(argvals, y, basisobj, Lfd = 2,
                                          log10_lambda_grid = seq(-6, 2, by = 0.25)) {
  gcv_vals <- numeric(length(log10_lambda_grid))
  for (i in seq_along(log10_lambda_grid)) {
    lam <- 10^log10_lambda_grid[i]
    fdpar <- fdPar(basisobj, Lfdobj = int2Lfd(Lfd), lambda = lam)
    sb <- smooth.basis(argvals = argvals, y = y, fdParobj = fdpar)
    gcv_vals[i] <- mean(as.numeric(sb$gcv), na.rm = TRUE)
  }
  i_best <- which.min(gcv_vals)
  list(
    lambda = 10^log10_lambda_grid[i_best],
    grid = data.frame(log10_lambda = log10_lambda_grid, gcv = gcv_vals)
  )
}

# Local band from residuals (loess on squared residuals) — used for pres_mean
pi_from_resid_loess <- function(tnum, resid, yhat, span = 0.25) {
  s2 <- resid^2
  s2[!is.finite(s2)] <- NA_real_
  global_sd <- sd(resid, na.rm = TRUE)
  if (!is.finite(global_sd) || global_sd <= 0) global_sd <- 1
  
  sd_loc <- rep(global_sd, length(resid))
  ok <- is.finite(tnum) & is.finite(s2)
  if (sum(ok) >= 10) {
    fit <- try(loess(s2 ~ tnum, span = span, degree = 1, na.action = na.exclude), silent = TRUE)
    if (!inherits(fit, "try-error")) {
      pred_s2 <- predict(fit, newdata = data.frame(tnum = tnum))
      pred_s2[!is.finite(pred_s2)] <- global_sd^2
      pred_s2 <- pmax(pred_s2, 0)
      sd_loc <- sqrt(pred_s2)
      sd_loc[!is.finite(sd_loc)] <- global_sd
    }
  }
  
  list(
    lo = yhat - 1.96 * sd_loc,
    hi = yhat + 1.96 * sd_loc
  )
}

# =========================
# 2) Daily FDA runner (Fourier + D2)
# =========================
run_fda_daily_fourier <- function(
    y_name,
    y_label,
    nbasis,
    period = 365.25,
    out_tag,                  # e.g., "tmed" or "pres_mean"
    table_name,               # e.g., "Tabla_3_1_metricas_FDA_tmed.csv"
    fig_train_name,           # e.g., "Fig_3_1a_FDA_tmed_train.png"
    fig_test_name,            # e.g., "Fig_3_1b_FDA_tmed_test.png"
    band_method = c("global_sd", "local_loess"),
    loess_span = 0.25
) {
  band_method <- match.arg(band_method)
  
  # --- Load data (all/train/test) ---
  all_path   <- path_in(FILE_ALL_DAILY)
  train_path <- path_in(FILE_TRAIN_DAILY)
  test_path  <- path_in(FILE_TEST_DAILY)
  
  if (!file.exists(all_path)) stop("Missing daily ALL file: ", all_path)
  if (!file.exists(train_path)) stop("Missing daily TRAIN file: ", train_path)
  if (!file.exists(test_path)) stop("Missing daily TEST file: ", test_path)
  
  all_df <- read_csv(all_path, show_col_types = FALSE) %>%
    mutate(fecha = as.Date(fecha)) %>%
    arrange(fecha) %>%
    mutate(t_idx = row_number())  # 1..800
  
  train_df <- read_csv(train_path, show_col_types = FALSE) %>%
    mutate(fecha = as.Date(fecha)) %>%
    left_join(all_df %>% select(fecha, t_idx), by = "fecha")
  
  test_df <- read_csv(test_path, show_col_types = FALSE) %>%
    mutate(fecha = as.Date(fecha)) %>%
    left_join(all_df %>% select(fecha, t_idx), by = "fecha")
  
  stopifnot(all(!is.na(train_df$t_idx)), all(!is.na(test_df$t_idx)))
  
  # --- Build variables ---
  t_train <- train_df$t_idx
  t_test  <- test_df$t_idx
  t_grid  <- all_df$t_idx
  date_grid <- all_df$fecha
  
  # pres_mean: compute if needed
  if (y_name == "pres_mean") {
    if (!("pres_mean" %in% names(train_df))) {
      if (all(c("presMax","presMin") %in% names(train_df))) {
        train_df <- train_df %>% mutate(pres_mean = (presMax + presMin)/2)
      } else stop("pres_mean not found and presMax/presMin not available in train.")
    }
    if (!("pres_mean" %in% names(test_df))) {
      if (all(c("presMax","presMin") %in% names(test_df))) {
        test_df <- test_df %>% mutate(pres_mean = (presMax + presMin)/2)
      } else stop("pres_mean not found and presMax/presMin not available in test.")
    }
    # linear interpolation for NA
    train_df$pres_mean <- lin_interp(as.numeric(train_df$pres_mean))
    test_df$pres_mean  <- lin_interp(as.numeric(test_df$pres_mean))
  }
  
  y_train <- as.numeric(train_df[[y_name]])
  y_test  <- as.numeric(test_df[[y_name]])
  
  # --- Basis + lambda selection (GCV on train) ---
  rangeval <- c(min(t_grid), max(t_grid))
  basis <- create.fourier.basis(rangeval = rangeval, nbasis = nbasis, period = period)
  
  sel <- select_lambda_gcv_smoothbasis(
    argvals = t_train, y = y_train, basisobj = basis, Lfd = 2,
    log10_lambda_grid = seq(-6, 2, by = 0.25)
  )
  lambda_hat <- sel$lambda
  
  fdpar <- fdPar(basis, Lfdobj = int2Lfd(2), lambda = lambda_hat)
  fit_train <- smooth.basis(argvals = t_train, y = y_train, fdParobj = fdpar)
  fd_hat <- fit_train$fd
  
  # --- Predictions on train/test/grid ---
  yhat_train <- as.numeric(eval.fd(t_train, fd_hat))
  yhat_test  <- as.numeric(eval.fd(t_test,  fd_hat))
  yhat_grid  <- as.numeric(eval.fd(t_grid,  fd_hat))
  
  # --- 95% band (pragmatic) ---
  if (band_method == "global_sd") {
    sigma_hat <- sd(y_train - yhat_train, na.rm = TRUE)
    lo_grid <- yhat_grid - 1.96 * sigma_hat
    hi_grid <- yhat_grid + 1.96 * sigma_hat
  } else {
    # local band based on loess of squared residuals on GRID index
    resid_grid <- approx(x = t_train, y = (y_train - yhat_train),
                         xout = t_grid, rule = 2)$y
    tmp <- pi_from_resid_loess(t_grid, resid_grid, yhat_grid, span = loess_span)
    lo_grid <- tmp$lo
    hi_grid <- tmp$hi
  }
  
  # --- Metrics ---
  metrics <- tibble::tibble(
    Modelo = paste0("FDA (Fourier + D2, nbasis=", nbasis, ")"),
    lambda = lambda_hat,
    MSE_train = mse(y_train, yhat_train),
    MAE_train = mae(y_train, yhat_train),
    R2_train  = r2(y_train, yhat_train),
    MSE_test  = mse(y_test,  yhat_test),
    MAE_test  = mae(y_test,  yhat_test),
    R2_test   = r2(y_test,   yhat_test)
  )
  
  write_csv(metrics, path_out(table_name))
  
  # --- Plots ---
  df_grid <- data.frame(
    fecha = date_grid,
    yhat  = yhat_grid,
    lo    = lo_grid,
    hi    = hi_grid
  )
  
  df_train_plot <- train_df %>% transmute(fecha, y = .data[[y_name]])
  df_test_plot  <- test_df  %>% transmute(fecha, y = .data[[y_name]])
  
  base_theme <- theme_bw(base_size = 14) +
    theme(plot.title = element_text(face = "bold"),
          axis.title = element_text(face = "bold"))
  
  p_train <- ggplot() +
    geom_ribbon(data = df_grid, aes(x = fecha, ymin = lo, ymax = hi), alpha = 0.25) +
    geom_line(data = df_grid, aes(x = fecha, y = yhat), linewidth = 1) +
    geom_point(data = df_train_plot, aes(x = fecha, y = y), size = 1.3) +
    labs(title = "Entrenamiento", x = "Fecha", y = y_label) +
    base_theme
  
  p_test <- ggplot() +
    geom_ribbon(data = df_grid, aes(x = fecha, ymin = lo, ymax = hi), alpha = 0.25) +
    geom_line(data = df_grid, aes(x = fecha, y = yhat), linewidth = 1) +
    geom_point(data = df_test_plot, aes(x = fecha, y = y), size = 1.3) +
    labs(title = "Prueba", x = "Fecha", y = y_label) +
    base_theme
  
  ggsave(path_out(fig_train_name), p_train, width = 6.5, height = 4.5, dpi = 180)
  ggsave(path_out(fig_test_name),  p_test,  width = 6.5, height = 4.5, dpi = 180)
  
  message("OK: ", out_tag, " | lambda_hat=", format(lambda_hat, scientific = TRUE))
  print(metrics)
  invisible(metrics)
}

# =========================
# 3) Hourly FDA runner (penalized LS + GCV) — your elec_FDA.R logic
# =========================
parse_datetime_safe <- function(x) {
  dt <- suppressWarnings(as.POSIXct(x, tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"))
  if (all(is.na(dt))) dt <- suppressWarnings(as.POSIXct(x, tz = "UTC"))
  dt
}

safe_solve <- function(M, b = NULL, ridge = 1e-8) {
  M2 <- M + diag(ridge, nrow(M))
  if (is.null(b)) return(solve(M2))
  solve(M2, b)
}

metrics_reg_df <- function(y, yhat) {
  data.frame(MSE = mse(y, yhat), MAE = mae(y, yhat), R2 = r2(y, yhat))
}

fit_fda_gcv <- function(t_train, y_train, t_full, basis_obj, lambda, Lfd = 2) {
  Btr   <- eval.basis(t_train, basis_obj)
  Bfull <- eval.basis(t_full,  basis_obj)
  R     <- getbasispenalty(basis_obj, Lfdobj = int2Lfd(Lfd))
  
  BtB <- crossprod(Btr)
  A   <- safe_solve(BtB + lambda * R)
  
  coef_hat <- A %*% crossprod(Btr, y_train)
  yhat_full <- as.numeric(Bfull %*% coef_hat)
  
  Str <- Btr %*% A %*% t(Btr)
  df_eff <- sum(diag(Str))
  yhat_tr <- as.numeric(Str %*% y_train)
  
  sse <- sum((y_train - yhat_tr)^2)
  ntr <- length(y_train)
  gcv <- (sse / ntr) / (1 - df_eff / ntr)^2
  
  denom <- max(1, (ntr - df_eff))
  sigma2 <- sse / denom
  
  Sfull <- Bfull %*% A %*% t(Btr)
  var_full <- sigma2 * rowSums(Sfull^2)
  
  list(yhat_full = yhat_full, gcv = gcv, df_eff = df_eff, sigma2 = sigma2, var_full = var_full)
}

select_lambda <- function(t_train, y_train, t_full, basis_obj, lambda_grid, Lfd = 2) {
  out <- vector("list", length(lambda_grid))
  for (i in seq_along(lambda_grid)) {
    lam <- lambda_grid[i]
    fit <- fit_fda_gcv(t_train, y_train, t_full, basis_obj, lam, Lfd = Lfd)
    out[[i]] <- data.frame(lambda = lam, gcv = fit$gcv, df_eff = fit$df_eff, sigma2 = fit$sigma2)
  }
  grid <- do.call(rbind, out)
  best_i <- which.min(grid$gcv)
  list(best_lambda = grid$lambda[best_i], grid = grid)
}

plot_split_hourly <- function(df_points, df_curve, title_txt, out_png) {
  p <- ggplot() +
    geom_ribbon(data = df_curve, aes(x = datetime, ymin = pi_low, ymax = pi_up), alpha = 0.25) +
    geom_line(data = df_curve, aes(x = datetime, y = y_hat), linewidth = 0.7) +
    geom_point(data = df_points, aes(x = datetime, y = y_obs), size = 1.5) +
    labs(title = title_txt, x = "Fecha", y = "Demanda (MW)") +
    theme_bw() +
    theme(plot.title = element_text(face = "bold"),
          axis.title = element_text(face = "bold"))
  ggsave(path_out(out_png), p, width = 14, height = 6, dpi = 150)
  invisible(p)
}

run_fda_hourly_spain_load <- function(
    split_mode = c("chronological", "uniform"),
    seed = 123
) {
  split_mode <- match.arg(split_mode)
  
  in_path <- path_in(FILE_SPAIN_LOAD)
  if (!file.exists(in_path)) {
    # fallback: try to find by pattern
    cand <- list.files(DATA_DIR, pattern = "spain_load.*clean.*\\.csv$", full.names = TRUE)
    if (length(cand) == 0) stop("Spain load file not found in DATA_DIR.")
    in_path <- cand[1]
  }
  
  df <- read.csv(in_path, stringsAsFactors = FALSE)
  
  col_dt <- intersect(names(df), c("datetime", "dttm", "date", "Fecha", "fecha", "time"))
  col_y  <- intersect(names(df), c("y", "load", "demanda", "demand", "MW", "value"))
  if (length(col_dt) == 0) stop("No datetime column found.")
  if (length(col_y)  == 0) stop("No load column found.")
  col_dt <- col_dt[1]
  col_y  <- col_y[1]
  
  dt <- parse_datetime_safe(df[[col_dt]])
  y  <- as.numeric(df[[col_y]])
  
  ord <- if (!all(is.na(dt))) order(dt) else seq_len(nrow(df))
  dt <- dt[ord]; y <- y[ord]
  
  n_keep <- 800
  if (length(y) < n_keep) stop("Load file has < 800 rows.")
  dt <- dt[1:n_keep]
  y  <- y[1:n_keep]
  t_full <- 1:n_keep
  
  # split 70/30
  n_train <- floor(0.7 * n_keep)  # 560
  if (split_mode == "chronological") {
    train_idx <- 1:n_train
  } else {
    set.seed(seed)
    train_idx <- sort(sample.int(n_keep, n_train))
  }
  test_idx <- setdiff(seq_len(n_keep), train_idx)
  
  t_train <- t_full[train_idx]
  y_train <- y[train_idx]
  
  lambda_grid <- 10^seq(-8, 2, length.out = 60)
  
  K_fourier <- 65
  K_bspline <- 60
  norder_bs <- 4
  
  basis_fourier <- create.fourier.basis(rangeval = c(min(t_full), max(t_full)), nbasis = K_fourier)
  basis_bspline <- create.bspline.basis(rangeval = c(min(t_full), max(t_full)),
                                        nbasis = K_bspline, norder = norder_bs)
  
  sel_F <- select_lambda(t_train, y_train, t_full, basis_fourier, lambda_grid, Lfd = 2)
  sel_B <- select_lambda(t_train, y_train, t_full, basis_bspline, lambda_grid, Lfd = 2)
  
  fit_F <- fit_fda_gcv(t_train, y_train, t_full, basis_fourier, sel_F$best_lambda, Lfd = 2)
  fit_B <- fit_fda_gcv(t_train, y_train, t_full, basis_bspline, sel_B$best_lambda, Lfd = 2)
  
  yhat_F <- fit_F$yhat_full
  yhat_B <- fit_B$yhat_full
  
  mF_test <- metrics_reg_df(y[test_idx], yhat_F[test_idx])
  mB_test <- metrics_reg_df(y[test_idx], yhat_B[test_idx])
  
  choose_basis <- if (mF_test$MSE <= mB_test$MSE) "Fourier" else "B-spline"
  if (choose_basis == "Fourier") {
    basis_name <- "Fourier"
    K_used <- K_fourier
    lambda_used <- sel_F$best_lambda
    fit <- fit_F
  } else {
    basis_name <- "B-spline"
    K_used <- K_bspline
    lambda_used <- sel_B$best_lambda
    fit <- fit_B
  }
  
  # Save combined GCV grid
  gF <- sel_F$grid; gF$basis <- "Fourier";  gF$K <- K_fourier
  gB <- sel_B$grid; gB$basis <- "B-spline"; gB$K <- K_bspline
  gcv_out <- rbind(gF, gB)
  gcv_out$chosen <- (gcv_out$basis == basis_name) & (abs(gcv_out$lambda - lambda_used) < 1e-30)
  write.csv(gcv_out, path_out("GCV_3_3_grid_spain_load.csv"), row.names = FALSE)
  
  # Predictions + 95% band
  yhat_full <- fit$yhat_full
  se_full <- sqrt(pmax(fit$var_full, 0))
  pi_low <- yhat_full - 1.96 * se_full
  pi_up  <- yhat_full + 1.96 * se_full
  
  df_curve <- data.frame(datetime = dt, y_hat = yhat_full, pi_low = pi_low, pi_up = pi_up)
  
  df_train_pts <- data.frame(datetime = dt[train_idx], y_obs = y[train_idx])
  df_test_pts  <- data.frame(datetime = dt[test_idx],  y_obs = y[test_idx])
  
  # Save pred tables
  pred_train <- data.frame(datetime = dt[train_idx], t = t_train, y_obs = y[train_idx],
                           y_hat = yhat_full[train_idx], pi_low = pi_low[train_idx], pi_up = pi_up[train_idx],
                           basis = basis_name, K = K_used, lambda = lambda_used, split_mode = split_mode)
  pred_test  <- data.frame(datetime = dt[test_idx], t = t_full[test_idx], y_obs = y[test_idx],
                           y_hat = yhat_full[test_idx], pi_low = pi_low[test_idx], pi_up = pi_up[test_idx],
                           basis = basis_name, K = K_used, lambda = lambda_used, split_mode = split_mode)
  
  write.csv(pred_train, path_out("pred_FDA_spain_load_train.csv"), row.names = FALSE)
  write.csv(pred_test,  path_out("pred_FDA_spain_load_test.csv"),  row.names = FALSE)
  
  # Metrics table
  m_train <- metrics_reg_df(y[train_idx], yhat_full[train_idx])
  m_test  <- metrics_reg_df(y[test_idx],  yhat_full[test_idx])
  
  tabla <- rbind(
    data.frame(split = "train", m_train),
    data.frame(split = "test",  m_test)
  )
  tabla$basis <- basis_name
  tabla$K <- K_used
  tabla$lambda <- lambda_used
  tabla$split_mode <- split_mode
  
  write.csv(tabla, path_out("Tabla_3_3_metricas_FDA_spain_load.csv"), row.names = FALSE)
  
  # Plots
  plot_split_hourly(df_train_pts, df_curve,
                    paste0("Entrenamiento (FDA) - Demanda eléctrica (MW) [", split_mode, "]"),
                    "Fig_3_3_FDA_spain_load_train.png")
  plot_split_hourly(df_test_pts, df_curve,
                    paste0("Prueba (FDA) - Demanda eléctrica (MW) [", split_mode, "]"),
                    "Fig_3_3_FDA_spain_load_test.png")
  
  message("OK: Spain load | basis=", basis_name, " K=", K_used,
          " lambda=", format(lambda_used, scientific = TRUE),
          " split_mode=", split_mode)
  print(tabla)
  invisible(tabla)
}

# =========================
# 4) Run all (Chapter 3.5 FDA)
# =========================
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

# 3.5.2.1 tmed
try({
  run_fda_daily_fourier(
    y_name = "tmed",
    y_label = "Temperatura media diaria (°C)",
    nbasis = 25,
    period = 365.25,
    out_tag = "tmed",
    table_name = "Tabla_3_1_metricas_FDA_tmed.csv",
    fig_train_name = "Fig_3_1a_FDA_tmed_train.png",
    fig_test_name  = "Fig_3_1b_FDA_tmed_test.png",
    band_method = "global_sd"
  )
}, silent = FALSE)

# 3.5.2.2 pres_mean
try({
  run_fda_daily_fourier(
    y_name = "pres_mean",
    y_label = "Presión media diaria (hPa)",
    nbasis = 65,
    period = 365.25,
    out_tag = "pres_mean",
    table_name = "Tabla_3_2_metricas_FDA_pres_mean.csv",
    fig_train_name = "Fig_3_2a_FDA_pres_mean_train.png",
    fig_test_name  = "Fig_3_2b_FDA_pres_mean_test.png",
    band_method = "local_loess",
    loess_span = 0.25
  )
}, silent = FALSE)

# 3.5.2.3 demanda eléctrica (default: chronological split; change to "uniform" if you want)
try({
  run_fda_hourly_spain_load(split_mode = "chronological", seed = 123)
  # If you want your old behavior (random uniform split):
  # run_fda_hourly_spain_load(split_mode = "uniform", seed = 123)
}, silent = FALSE)

message("=== DONE: Chapter 3.5 FDA script finished. Outputs in OUT_DIR ===")
