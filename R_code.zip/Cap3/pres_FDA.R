############################################################
# 3.5.2.2 FDA - Presión media diaria (pres_mean) - Madrid Retiro
# Outputs:
#   - Fig_3_2a_FDA_pres_mean_train.png
#   - Fig_3_2b_FDA_pres_mean_test.png
#   - Tabla_3_2_metricas_FDA_pres_mean.csv
#   - GCV_3_2_grid_pres_mean.csv
#   - pred_FDA_pres_mean_train.csv / pred_FDA_pres_mean_test.csv
############################################################

# -------------------------
# 0) Packages (safe load)
# -------------------------
pkgs <- c("fda", "ggplot2", "dplyr", "readr", "lubridate")
need <- pkgs[!vapply(pkgs, requireNamespace, FUN.VALUE = logical(1), quietly = TRUE)]
if (length(need) > 0) {
  message("Missing packages: ", paste(need, collapse = ", "))
  message("Installing missing packages...")
  install.packages(need)
}
library(fda)
library(ggplot2)
library(dplyr)
library(readr)
library(lubridate)

# -------------------------
# 1) File paths
# -------------------------
DATA_DIR <- "."

train_path <- file.path(DATA_DIR, "retiro_3195_train_560_3195_2018-01-01_2020-03-10_uniform.csv")
test_path  <- file.path(DATA_DIR, "retiro_3195_test_240_3195_2018-01-01_2020-03-10_uniform.csv")

# fallback: auto-search by pattern if the exact name differs
if (!file.exists(train_path)) {
  cand <- list.files(DATA_DIR, pattern = "retiro_3195_train_.*\\.csv$", full.names = TRUE)
  if (length(cand) == 0) stop("Train file not found. Put the train CSV in DATA_DIR or adjust train_path.")
  train_path <- cand[1]
}
if (!file.exists(test_path)) {
  cand <- list.files(DATA_DIR, pattern = "retiro_3195_test_.*\\.csv$", full.names = TRUE)
  if (length(cand) == 0) stop("Test file not found. Put the test CSV in DATA_DIR or adjust test_path.")
  test_path <- cand[1]
}

message("Using train: ", train_path)
message("Using test : ", test_path)

# -------------------------
# 2) Helpers
# -------------------------
lin_interp <- function(x) {
  # base R linear interpolation for NA
  if (!anyNA(x)) return(x)
  idx <- seq_along(x)
  ok <- !is.na(x)
  if (sum(ok) < 2) return(x)
  x[!ok] <- approx(idx[ok], x[ok], xout = idx[!ok], method = "linear", rule = 2)$y
  x
}

metrics_reg <- function(y, yhat) {
  y <- as.numeric(y); yhat <- as.numeric(yhat)
  ok <- is.finite(y) & is.finite(yhat)
  y <- y[ok]; yhat <- yhat[ok]
  mse <- mean((y - yhat)^2)
  mae <- mean(abs(y - yhat))
  ss_res <- sum((y - yhat)^2)
  ss_tot <- sum((y - mean(y))^2)
  r2 <- 1 - ss_res / ss_tot
  c(MSE = mse, MAE = mae, R2 = r2)
}

# local (heteroskedastic-like) band from residuals via loess on squared residuals
pi_from_resid <- function(tnum, resid, yhat, span = 0.25) {
  s2 <- resid^2
  # robust fallbacks
  s2[!is.finite(s2)] <- NA_real_
  global_sd <- sd(resid, na.rm = TRUE)
  if (!is.finite(global_sd) || global_sd <= 0) global_sd <- 1
  
  # loess may fail if too few points; fallback to global
  sd_loc <- rep(global_sd, length(resid))
  ok <- is.finite(tnum) & is.finite(s2)
  if (sum(ok) >= 10) {
    fit <- try(loess(s2 ~ tnum, span = span, degree = 1, na.action = na.exclude), silent = TRUE)
    if (!inherits(fit, "try-error")) {
      pred_s2 <- predict(fit, newdata = data.frame(tnum = tnum))
      pred_s2[!is.finite(pred_s2)] <- global_sd^2
      pred_s2 <- pmax(pred_s2, 0)
      sd_loc <- sqrt(pred_s2)
      sd_loc[!is.finite(sd_loc)] <- global_sd
    }
  }
  
  lo <- yhat - 1.96 * sd_loc
  hi <- yhat + 1.96 * sd_loc
  list(lo = lo, hi = hi, sd_loc = sd_loc)
}

# -------------------------
# 3) Read data
# -------------------------
train <- suppressWarnings(readr::read_csv(train_path, show_col_types = FALSE))
test  <- suppressWarnings(readr::read_csv(test_path,  show_col_types = FALSE))

# expected columns: fecha, pres_mean 
# normalize date column name
date_col <- NULL
for (nm in c("fecha", "Fecha", "date", "Date")) {
  if (nm %in% names(train)) { date_col <- nm; break }
}
if (is.null(date_col)) stop("No date column found (expected 'fecha' or 'date').")

train <- train %>% mutate(fecha = as.Date(.data[[date_col]]))
test  <- test  %>% mutate(fecha = as.Date(.data[[date_col]]))

# pres_mean: use existing or compute from presMax/presMin
if (!("pres_mean" %in% names(train))) {
  if (all(c("presMax","presMin") %in% names(train))) {
    train <- train %>% mutate(pres_mean = (presMax + presMin) / 2)
  } else {
    stop("pres_mean not found and presMax/presMin not available to compute it.")
  }
}
if (!("pres_mean" %in% names(test))) {
  if (all(c("presMax","presMin") %in% names(test))) {
    test <- test %>% mutate(pres_mean = (presMax + presMin) / 2)
  } else {
    stop("pres_mean not found in test and presMax/presMin not available to compute it.")
  }
}

# sort by date (important for plotting and smooth stability)
train <- train %>% arrange(fecha)
test  <- test  %>% arrange(fecha)

# impute NA by linear interpolation
train$pres_mean <- lin_interp(as.numeric(train$pres_mean))
test$pres_mean  <- lin_interp(as.numeric(test$pres_mean))

# build a common time index in DAYS from the global min date
min_date <- min(c(train$fecha, test$fecha), na.rm = TRUE)
train <- train %>% mutate(tnum = as.numeric(fecha - min_date) + 1)
test  <- test  %>% mutate(tnum = as.numeric(fecha - min_date) + 1)

# range for basis
t_range <- range(c(train$tnum, test$tnum), na.rm = TRUE)

# -------------------------
# 4) FDA smoothing setup (Fourier + 2nd-derivative penalty)
# -------------------------
# Fourier nbasis should be odd; K controls flexibility.
K <- 65  
period_days <- 365.25

basis <- create.fourier.basis(rangeval = t_range, nbasis = K, period = period_days)
Lfdobj <- int2Lfd(2)  # roughness penalty based on 2nd derivative

# -------------------------
# 5) Choose lambda by GCV grid (training only)
# -------------------------
lambda_grid <- 10^seq(-8, 8, length.out = 61)

gcv_mean <- numeric(length(lambda_grid))

y_train <- train$pres_mean
t_train <- train$tnum

for (i in seq_along(lambda_grid)) {
  lam <- lambda_grid[i]
  fdParobj <- fdPar(basis, Lfdobj = Lfdobj, lambda = lam)
  sb <- smooth.basis(argvals = t_train, y = y_train, fdParobj = fdParobj)
  # sb$gcv is length n; take mean as summary
  gcv_mean[i] <- mean(sb$gcv, na.rm = TRUE)
}

best_i <- which.min(gcv_mean)
lambda_hat <- lambda_grid[best_i]

gcv_tbl <- data.frame(
  lambda = lambda_grid,
  gcv_mean = gcv_mean
) %>% arrange(lambda)

readr::write_csv(gcv_tbl, "GCV_3_2_grid_pres_mean.csv")
message("Selected lambda_hat = ", format(lambda_hat, scientific = TRUE))

# -------------------------
# 6) Fit smoothing with lambda_hat (train + test)
# -------------------------
fdPar_best <- fdPar(basis, Lfdobj = Lfdobj, lambda = lambda_hat)

fit_train <- smooth.basis(argvals = t_train, y = y_train, fdParobj = fdPar_best)
fd_train <- fit_train$fd
yhat_train <- as.numeric(eval.fd(t_train, fd_train))
res_train <- y_train - yhat_train

fit_test <- smooth.basis(argvals = test$tnum, y = test$pres_mean, fdParobj = fdPar_best)
fd_test <- fit_test$fd
yhat_test <- as.numeric(eval.fd(test$tnum, fd_test))
res_test <- test$pres_mean - yhat_test

# 95% PI (pragmatic, residual-based; gives a visually stable band)
pi_train <- pi_from_resid(train$tnum, res_train, yhat_train, span = 0.25)
pi_test  <- pi_from_resid(test$tnum,  res_test,  yhat_test,  span = 0.35)

train_out <- train %>%
  transmute(
    split = "train",
    fecha,
    tnum,
    y_obs = pres_mean,
    y_hat = yhat_train,
    lo_95 = pi_train$lo,
    hi_95 = pi_train$hi
  )

test_out <- test %>%
  transmute(
    split = "test",
    fecha,
    tnum,
    y_obs = pres_mean,
    y_hat = yhat_test,
    lo_95 = pi_test$lo,
    hi_95 = pi_test$hi
  )

readr::write_csv(train_out, "pred_FDA_pres_mean_train.csv")
readr::write_csv(test_out,  "pred_FDA_pres_mean_test.csv")

# -------------------------
# 7) Metrics table
# -------------------------
m_train <- metrics_reg(train_out$y_obs, train_out$y_hat)
m_test  <- metrics_reg(test_out$y_obs,  test_out$y_hat)

tabla <- tibble::tibble(
  Modelo = paste0("FDA (Fourier K=", K, ", lambda=", format(lambda_hat, scientific = TRUE), ")"),
  MSE_train = m_train["MSE"], MAE_train = m_train["MAE"], R2_train = m_train["R2"],
  MSE_test  = m_test["MSE"],  MAE_test  = m_test["MAE"],  R2_test  = m_test["R2"]
)

readr::write_csv(tabla, "Tabla_3_2_metricas_FDA_pres_mean.csv")
print(tabla)

# -------------------------
# 8) Plots (two separate files)
# -------------------------
base_theme <- theme_bw(base_size = 18) +
  theme(
    plot.title = element_text(face = "bold"),
    axis.title = element_text(face = "bold"),
    legend.position = "none"
  )

p_train <- ggplot(train_out, aes(x = fecha)) +
  geom_ribbon(aes(ymin = lo_95, ymax = hi_95), fill = "grey75", alpha = 0.8) +
  geom_point(aes(y = y_obs), size = 1.8) +
  geom_line(aes(y = y_hat), linewidth = 1.2) +
  labs(
    title = "Entrenamiento",
    x = "Fecha",
    y = "Presión media diaria (hPa)"
  ) + base_theme

p_test <- ggplot(test_out, aes(x = fecha)) +
  geom_ribbon(aes(ymin = lo_95, ymax = hi_95), fill = "grey75", alpha = 0.8) +
  geom_point(aes(y = y_obs), size = 1.8) +
  geom_line(aes(y = y_hat), linewidth = 1.2) +
  labs(
    title = "Prueba",
    x = "Fecha",
    y = "Presión media diaria (hPa)"
  ) + base_theme

ggsave("Fig_3_2a_FDA_pres_mean_train.png", p_train, width = 12.5, height = 7.5, dpi = 150)
ggsave("Fig_3_2b_FDA_pres_mean_test.png",  p_test,  width = 12.5, height = 7.5, dpi = 150)

message("Done. Files generated:")
message("  - Fig_3_2a_FDA_pres_mean_train.png")
message("  - Fig_3_2b_FDA_pres_mean_test.png")
message("  - Tabla_3_2_metricas_FDA_pres_mean.csv")
message("  - GCV_3_2_grid_pres_mean.csv")
message("  - pred_FDA_pres_mean_train.csv / pred_FDA_pres_mean_test.csv")
