############################################################
# 3.5.2.3 FDA - Demanda eléctrica España (serie horaria)
# Outputs to current working directory:
#   - Fig_3_3_FDA_spain_load_train.png
#   - Fig_3_3_FDA_spain_load_test.png
#   - GCV_3_3_grid_spain_load.csv
#   - pred_FDA_spain_load_train.csv
#   - pred_FDA_spain_load_test.csv
#   - Tabla_3_3_metricas_FDA_spain_load.csv
############################################################

# -------------------------
# 0) packages
# -------------------------
pkgs <- c("fda", "ggplot2")
for (p in pkgs) {
  if (!requireNamespace(p, quietly = TRUE)) {
    install.packages(p, dependencies = TRUE)
  }
}
suppressPackageStartupMessages({
  library(fda)
  library(ggplot2)
})

# -------------------------
# 1) helpers
# -------------------------
locate_file <- function(fname) {
  if (file.exists(fname)) return(fname)
  hits <- list.files(path = ".", pattern = paste0("^", fname, "$"),
                     recursive = TRUE, full.names = TRUE)
  if (length(hits) >= 1) return(hits[1])
  stop(sprintf("No existe: %s (no encontrado en el directorio actual).", fname))
}

parse_datetime_safe <- function(x) {
  # Accept ISO like 2019-01-01T00:00:00Z
  dt <- suppressWarnings(as.POSIXct(x, tz = "UTC",
                                    format = "%Y-%m-%dT%H:%M:%SZ"))
  if (all(is.na(dt))) {
    # fallback try without Z
    dt <- suppressWarnings(as.POSIXct(x, tz = "UTC"))
  }
  dt
}

safe_solve <- function(M, b = NULL, ridge = 1e-8) {
  # add small ridge if near-singular
  M2 <- M + diag(ridge, nrow(M))
  if (is.null(b)) return(solve(M2))
  solve(M2, b)
}

metrics_reg <- function(y, yhat) {
  mse <- mean((y - yhat)^2)
  mae <- mean(abs(y - yhat))
  sst <- sum((y - mean(y))^2)
  sse <- sum((y - yhat)^2)
  r2  <- if (sst > 0) 1 - sse/sst else NA_real_
  data.frame(MSE = mse, MAE = mae, R2 = r2)
}

# Penalized least squares smoother + GCV (irregular points ok)
fit_fda_gcv <- function(t_train, y_train, t_full, basis_obj, lambda, Lfd = 2) {
  Btr   <- eval.basis(t_train, basis_obj)                 # n_train x K
  Bfull <- eval.basis(t_full,  basis_obj)                 # n_full  x K
  R     <- getbasispenalty(basis_obj, Lfdobj = int2Lfd(Lfd))
  
  # A = (B'B + lambda R)^-1
  BtB <- crossprod(Btr)                                   # K x K
  A   <- safe_solve(BtB + lambda * R)
  
  # coef = A B' y
  coef_hat <- A %*% crossprod(Btr, y_train)              # K x 1
  
  # fitted on full grid
  yhat_full <- as.numeric(Bfull %*% coef_hat)
  
  # Hat matrices to estimate df and pointwise variance bands
  Str <- Btr   %*% A %*% t(Btr)                          # n_train x n_train
  df_eff <- sum(diag(Str))
  yhat_tr <- as.numeric(Str %*% y_train)
  
  sse <- sum((y_train - yhat_tr)^2)
  ntr <- length(y_train)
  gcv <- (sse / ntr) / (1 - df_eff / ntr)^2
  
  # sigma^2 estimate
  denom <- max(1, (ntr - df_eff))
  sigma2 <- sse / denom
  
  # mapping from y_train to full fitted: Sfull = Bfull A Btr'
  Sfull <- Bfull %*% A %*% t(Btr)                        # n_full x n_train
  var_full <- sigma2 * rowSums(Sfull^2)                  # diag(Sfull Sfull')
  
  list(
    yhat_full = yhat_full,
    gcv = gcv,
    df_eff = df_eff,
    sigma2 = sigma2,
    var_full = var_full,
    coef = coef_hat
  )
}

# Choose lambda by minimizing GCV over grid
select_lambda <- function(t_train, y_train, t_full, basis_obj, lambda_grid, Lfd = 2) {
  out <- vector("list", length(lambda_grid))
  for (i in seq_along(lambda_grid)) {
    lam <- lambda_grid[i]
    fit <- fit_fda_gcv(t_train, y_train, t_full, basis_obj, lam, Lfd = Lfd)
    out[[i]] <- data.frame(
      lambda = lam,
      gcv = fit$gcv,
      df_eff = fit$df_eff,
      sigma2 = fit$sigma2
    )
  }
  grid <- do.call(rbind, out)
  best_i <- which.min(grid$gcv)
  list(best_lambda = grid$lambda[best_i], grid = grid)
}

plot_split <- function(df_points, df_curve, title_txt, out_png) {
  p <- ggplot() +
    geom_ribbon(data = df_curve,
                aes(x = datetime, ymin = pi_low, ymax = pi_up),
                alpha = 0.25) +
    geom_line(data = df_curve,
              aes(x = datetime, y = y_hat),
              linewidth = 0.7) +
    geom_point(data = df_points,
               aes(x = datetime, y = y_obs),
               size = 1.5) +
    labs(title = title_txt, x = "Fecha", y = "Demanda (MW)") +
    theme_bw() +
    theme(
      plot.title = element_text(face = "bold"),
      axis.title = element_text(face = "bold")
    )
  ggsave(out_png, p, width = 14, height = 6, dpi = 150)
  invisible(p)
}

# -------------------------
# 2) load data (current dir)
# -------------------------
file_in <- locate_file("spain_load_hourly800_800_clean.csv")
df <- read.csv(file_in, stringsAsFactors = FALSE)

# Robust column detection (avoid your previous "undefined columns" error)
# Expect either: x/index, datetime/dttm/date, y/load/demanda
col_dt <- intersect(names(df), c("datetime", "dttm", "date", "Fecha", "fecha", "time"))
col_y  <- intersect(names(df), c("y", "load", "demanda", "demand", "MW", "value"))
if (length(col_dt) == 0) stop("No se encuentra columna de fecha/hora (datetime/dttm/date...).")
if (length(col_y)  == 0) stop("No se encuentra columna de demanda (y/load/demanda...).")
col_dt <- col_dt[1]
col_y  <- col_y[1]

dt <- parse_datetime_safe(df[[col_dt]])
y  <- as.numeric(df[[col_y]])

# Order by datetime if possible, else keep original
ord <- if (!all(is.na(dt))) order(dt) else seq_len(nrow(df))
df  <- df[ord, ]
dt  <- dt[ord]
y   <- y[ord]

# keep 800 consecutive observations (as your chapter states)
n_keep <- 800
if (nrow(df) < n_keep) stop(sprintf("El archivo tiene %d filas (< 800).", nrow(df)))
df <- df[1:n_keep, ]
dt <- dt[1:n_keep]
y  <- y[1:n_keep]

# define continuous axis t = 1..800 (stable numerically)
t_full <- 1:n_keep

# -------------------------
# 3) split 7:3 (uniform, reproducible)
# -------------------------
set.seed(123)
n_train <- floor(0.7 * n_keep)   # 560
train_idx <- sort(sample.int(n_keep, n_train))
test_idx  <- setdiff(seq_len(n_keep), train_idx)

t_train <- t_full[train_idx]
y_train <- y[train_idx]

# -------------------------
# 4) bases + lambda grid
# -------------------------
lambda_grid <- 10^seq(-8, 2, length.out = 60)

# Heuristic K for hourly series (you can tune)
K_fourier <- 65
K_bspline <- 60
norder_bs <- 4

basis_fourier <- create.fourier.basis(rangeval = c(min(t_full), max(t_full)),
                                      nbasis = K_fourier)
basis_bspline <- create.bspline.basis(rangeval = c(min(t_full), max(t_full)),
                                      nbasis = K_bspline,
                                      norder = norder_bs)

# Select lambda by GCV (train)
sel_F <- select_lambda(t_train, y_train, t_full, basis_fourier, lambda_grid, Lfd = 2)
sel_B <- select_lambda(t_train, y_train, t_full, basis_bspline, lambda_grid, Lfd = 2)

# Fit with best lambda for each basis
fit_F <- fit_fda_gcv(t_train, y_train, t_full, basis_fourier, sel_F$best_lambda, Lfd = 2)
fit_B <- fit_fda_gcv(t_train, y_train, t_full, basis_bspline, sel_B$best_lambda, Lfd = 2)

# Compare by test MSE (as your text states: choose lower error + stability)
yhat_F <- fit_F$yhat_full
yhat_B <- fit_B$yhat_full
mtr_F_test <- metrics_reg(y[test_idx], yhat_F[test_idx])
mtr_B_test <- metrics_reg(y[test_idx], yhat_B[test_idx])

choose_basis <- if (mtr_F_test$MSE <= mtr_B_test$MSE) "fourier" else "bspline"
if (choose_basis == "fourier") {
  basis_name <- "Fourier"
  K_used <- K_fourier
  lambda_used <- sel_F$best_lambda
  fit <- fit_F
  gcv_grid_F <- sel_F$grid
  gcv_grid_B <- sel_B$grid
} else {
  basis_name <- "B-spline"
  K_used <- K_bspline
  lambda_used <- sel_B$best_lambda
  fit <- fit_B
  gcv_grid_F <- sel_F$grid
  gcv_grid_B <- sel_B$grid
}

# Build a single GCV grid table to save
gcv_grid_F$basis <- "Fourier";  gcv_grid_F$K <- K_fourier
gcv_grid_B$basis <- "B-spline"; gcv_grid_B$K <- K_bspline
gcv_out <- rbind(gcv_grid_F, gcv_grid_B)
gcv_out$chosen <- (gcv_out$basis == basis_name) & (abs(gcv_out$lambda - lambda_used) < 1e-30)

write.csv(gcv_out, "GCV_3_3_grid_spain_load.csv", row.names = FALSE)

# -------------------------
# 5) predictions + 95% band
# -------------------------
yhat_full <- fit$yhat_full
se_full <- sqrt(pmax(fit$var_full, 0))
pi_low <- yhat_full - 1.96 * se_full
pi_up  <- yhat_full + 1.96 * se_full

df_curve <- data.frame(
  t = t_full,
  datetime = dt,
  y_hat = yhat_full,
  pi_low = pi_low,
  pi_up = pi_up
)

df_train_pts <- data.frame(
  t = t_train,
  datetime = dt[train_idx],
  y_obs = y[train_idx]
)

df_test_pts <- data.frame(
  t = t_full[test_idx],
  datetime = dt[test_idx],
  y_obs = y[test_idx]
)

# Save prediction tables (train/test)
pred_train <- data.frame(
  datetime = dt[train_idx],
  t = t_train,
  y_obs = y[train_idx],
  y_hat = yhat_full[train_idx],
  pi_low = pi_low[train_idx],
  pi_up  = pi_up[train_idx],
  basis = basis_name,
  K = K_used,
  lambda = lambda_used
)
pred_test <- data.frame(
  datetime = dt[test_idx],
  t = t_full[test_idx],
  y_obs = y[test_idx],
  y_hat = yhat_full[test_idx],
  pi_low = pi_low[test_idx],
  pi_up  = pi_up[test_idx],
  basis = basis_name,
  K = K_used,
  lambda = lambda_used
)

write.csv(pred_train, "pred_FDA_spain_load_train.csv", row.names = FALSE)
write.csv(pred_test,  "pred_FDA_spain_load_test.csv",  row.names = FALSE)

# -------------------------
# 6) metrics table
# -------------------------
mtr_train <- metrics_reg(y[train_idx], yhat_full[train_idx])
mtr_test  <- metrics_reg(y[test_idx],  yhat_full[test_idx])

tabla <- rbind(
  data.frame(split = "train", mtr_train),
  data.frame(split = "test",  mtr_test)
)
tabla$basis  <- basis_name
tabla$K      <- K_used
tabla$lambda <- lambda_used

write.csv(tabla, "Tabla_3_3_metricas_FDA_spain_load.csv", row.names = FALSE)

# -------------------------
# 7) plots (two figures)
# -------------------------
plot_split(
  df_points = df_train_pts,
  df_curve  = df_curve,
  title_txt = "Entrenamiento (FDA) - Demanda eléctrica (MW)",
  out_png   = "Fig_3_3_FDA_spain_load_train.png"
)

plot_split(
  df_points = df_test_pts,
  df_curve  = df_curve,
  title_txt = "Prueba (FDA) - Demanda eléctrica (MW)",
  out_png   = "Fig_3_3_FDA_spain_load_test.png"
)

cat("====================================================\n")
cat("FDA 3.5.2.3 terminado.\n")
cat("Archivo leído:", file_in, "\n")
cat("Base elegida:", basis_name, "  K =", K_used, "  lambda =", format(lambda_used, scientific = TRUE), "\n")
cat("Salidas en directorio actual:\n")
cat(" - Fig_3_3_FDA_spain_load_train.png\n")
cat(" - Fig_3_3_FDA_spain_load_test.png\n")
cat(" - GCV_3_3_grid_spain_load.csv\n")
cat(" - pred_FDA_spain_load_train.csv\n")
cat(" - pred_FDA_spain_load_test.csv\n")
cat(" - Tabla_3_3_metricas_FDA_spain_load.csv\n")
cat("====================================================\n")
