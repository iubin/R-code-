############################################################
# 3.5.2.4 - Suavizado local (kernel cuadrático, span=25%)
# - Proyección y vs t (train/test)
# - Superficie yhat(x1,x2) entrenada + puntos train/test
# - Exporta: pred_FDA_sim_train.csv, pred_FDA_sim_test.csv
#           Tabla_3_4_metricas_FDA_sim.csv
#           Fig_3_4a/b/c/d_*.png
# Todo se guarda en el directorio de trabajo (getwd()).
############################################################


if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
library(ggplot2)

# ============== 1) config ==============
TRAIN_FILE <- "sim_data_train.csv"
TEST_FILE  <- "sim_data_test.csv"

SPAN <- 0.25              # 25% del tamaño muestral
NGRID_T <- 400            # densidad de la curva en t
NGRID_SURF <- 80          # 80x80 para superficie (ajusta si quieres más detalle)

# Para que la superficie no quede "vacía" por extremos, usa cuantiles:
USE_QUANTILE_LIMITS <- TRUE
QLIM <- c(0.01, 0.99)

# ============== 2) utilidades ==============
stop_if_missing <- function(path) {
  if (!file.exists(path)) stop(paste0("No existe el archivo: ", path))
}

mse <- function(y, yhat) mean((y - yhat)^2, na.rm = TRUE)
mae <- function(y, yhat) mean(abs(y - yhat), na.rm = TRUE)
r2  <- function(y, yhat) {
  sse <- sum((y - yhat)^2, na.rm = TRUE)
  sst <- sum((y - mean(y, na.rm = TRUE))^2, na.rm = TRUE)
  1 - sse / sst
}

# Kernel cuadrático (Epanechnikov)
k_quad <- function(u) pmax(0, 1 - u^2)

# ============== 3) suavizado local 1D (y vs t) ==============
# Para evitar inestabilidad por muchos t repetidos:
# 1) agregamos por t (media) y suavizamos la media.
aggregate_by_t <- function(df) {
  # df: columnas t,y
  agg_mean <- aggregate(y ~ t, df, mean)
  agg_sd   <- aggregate(y ~ t, df, sd)
  agg_n    <- aggregate(y ~ t, df, length)
  names(agg_mean)[2] <- "y_mean"
  names(agg_sd)[2]   <- "y_sd"
  names(agg_n)[2]    <- "n"
  out <- merge(merge(agg_mean, agg_sd, by = "t", all = TRUE),
               agg_n, by = "t", all = TRUE)
  out$y_sd[is.na(out$y_sd)] <- 0
  out
}

# Predicción local lineal en un punto x0 usando k vecinos (span*n)
local_linear_1d_point <- function(x, y, x0, span = 0.25, eps = 1e-12) {
  n <- length(x)
  k <- max(5, ceiling(span * n))
  
  d <- abs(x - x0)
  idx <- order(d)[seq_len(k)]
  h <- max(d[idx]) + eps
  
  u <- d[idx] / h
  w <- k_quad(u)
  
  xc <- x[idx] - x0
  X <- cbind(1, xc)
  ysub <- y[idx]
  
  XtW  <- t(X * w)
  XtWX <- XtW %*% X
  XtWy <- XtW %*% ysub
  
  beta <- tryCatch(solve(XtWX, XtWy), error = function(e) NULL)
  
  if (is.null(beta) || any(!is.finite(beta))) {
    yhat <- sum(w * ysub) / sum(w)
    sdw  <- sqrt(sum(w * (ysub - yhat)^2) / sum(w))
    return(list(yhat = yhat, sd = sdw))
  }
  
  yhat <- as.numeric(beta[1])  # predicción en x0
  yfit <- as.numeric(X %*% beta)
  sdw  <- sqrt(sum(w * (ysub - yfit)^2) / sum(w))
  list(yhat = yhat, sd = sdw)
}

local_linear_1d_vec <- function(x, y, x0_vec, span = 0.25) {
  yhat <- numeric(length(x0_vec))
  sdv  <- numeric(length(x0_vec))
  for (i in seq_along(x0_vec)) {
    tmp <- local_linear_1d_point(x, y, x0_vec[i], span = span)
    yhat[i] <- tmp$yhat
    sdv[i]  <- tmp$sd
  }
  data.frame(x0 = x0_vec, yhat = yhat, sd = sdv)
}

# ============== 4) suavizado local 2D (superficie yhat(x1,x2)) ==============
# Distancia en espacio estandarizado (mejor escalado)
local_linear_2d_point <- function(z1, z2, y, z10, z20, span = 0.25, eps = 1e-12) {
  n <- length(y)
  k <- max(20, ceiling(span * n))
  
  d <- sqrt((z1 - z10)^2 + (z2 - z20)^2)
  idx <- order(d)[seq_len(k)]
  h <- max(d[idx]) + eps
  
  u <- d[idx] / h
  w <- k_quad(u)
  
  X <- cbind(1, (z1[idx] - z10), (z2[idx] - z20))
  ysub <- y[idx]
  
  XtW  <- t(X * w)
  XtWX <- XtW %*% X
  XtWy <- XtW %*% ysub
  
  beta <- tryCatch(solve(XtWX, XtWy), error = function(e) NULL)
  
  if (is.null(beta) || any(!is.finite(beta))) {
    return(sum(w * ysub) / sum(w))
  }
  as.numeric(beta[1])
}

surface_predict <- function(train_df, x1_seq, x2_seq, span = 0.25) {
  # estandariza con stats de train
  mu1 <- mean(train_df$x1); sd1 <- sd(train_df$x1)
  mu2 <- mean(train_df$x2); sd2 <- sd(train_df$x2)
  z1  <- (train_df$x1 - mu1) / sd1
  z2  <- (train_df$x2 - mu2) / sd2
  y   <- train_df$y
  
  grid <- expand.grid(x1 = x1_seq, x2 = x2_seq)
  # z de los puntos grid
  gz1 <- (grid$x1 - mu1) / sd1
  gz2 <- (grid$x2 - mu2) / sd2
  
  yhat <- numeric(nrow(grid))
  for (i in seq_len(nrow(grid))) {
    yhat[i] <- local_linear_2d_point(z1, z2, y, gz1[i], gz2[i], span = span)
  }
  grid$yhat <- yhat
  grid
}

# ============== 5) lectura de datos ==============
stop_if_missing(TRAIN_FILE)
stop_if_missing(TEST_FILE)

df_tr <- read.csv(TRAIN_FILE)
df_te <- read.csv(TEST_FILE)

# Asegura columnas esperadas
need_cols <- c("t", "x1", "x2", "y")
if (!all(need_cols %in% names(df_tr))) stop("Train no tiene columnas: t,x1,x2,y")
if (!all(need_cols %in% names(df_te))) stop("Test no tiene columnas: t,x1,x2,y")

# ============== 6) proyección y vs t (train/test) ==============
# suavizamos sobre la media por t
tr_agg <- aggregate_by_t(df_tr[, c("t","y")])
te_agg <- aggregate_by_t(df_te[, c("t","y")])

t_grid_tr <- seq(min(tr_agg$t), max(tr_agg$t), length.out = NGRID_T)
t_grid_te <- seq(min(te_agg$t), max(te_agg$t), length.out = NGRID_T)

fit_tr_grid <- local_linear_1d_vec(tr_agg$t, tr_agg$y_mean, t_grid_tr, span = SPAN)
fit_te_grid <- local_linear_1d_vec(te_agg$t, te_agg$y_mean, t_grid_te, span = SPAN)

# predicción en los puntos originales (para métricas)
fit_tr_pts <- local_linear_1d_vec(tr_agg$t, tr_agg$y_mean, df_tr$t, span = SPAN)
fit_te_pts <- local_linear_1d_vec(te_agg$t, te_agg$y_mean, df_te$t, span = SPAN)

# intervalos simples (±1.96*sd)
fit_tr_grid$lwr <- fit_tr_grid$yhat - 1.96 * fit_tr_grid$sd
fit_tr_grid$upr <- fit_tr_grid$yhat + 1.96 * fit_tr_grid$sd
fit_te_grid$lwr <- fit_te_grid$yhat - 1.96 * fit_te_grid$sd
fit_te_grid$upr <- fit_te_grid$yhat + 1.96 * fit_te_grid$sd

pred_tr <- cbind(df_tr, yhat = fit_tr_pts$yhat,
                 lwr = fit_tr_pts$yhat - 1.96 * fit_tr_pts$sd,
                 upr = fit_tr_pts$yhat + 1.96 * fit_tr_pts$sd)
pred_te <- cbind(df_te, yhat = fit_te_pts$yhat,
                 lwr = fit_te_pts$yhat - 1.96 * fit_te_pts$sd,
                 upr = fit_te_pts$yhat + 1.96 * fit_te_pts$sd)

# métricas (sobre puntos individuales)
tabla <- data.frame(
  Modelo   = "Suavizado local (kernel cuadrático, span=0.25)",
  MSE_train = mse(pred_tr$y, pred_tr$yhat),
  MAE_train = mae(pred_tr$y, pred_tr$yhat),
  R2_train  = r2(pred_tr$y, pred_tr$yhat),
  MSE_test  = mse(pred_te$y, pred_te$yhat),
  MAE_test  = mae(pred_te$y, pred_te$yhat),
  R2_test   = r2(pred_te$y, pred_te$yhat)
)

# exporta a directorio actual
write.csv(pred_tr, "pred_FDA_sim_train.csv", row.names = FALSE)
write.csv(pred_te, "pred_FDA_sim_test.csv", row.names = FALSE)
write.csv(tabla,  "Tabla_3_4_metricas_FDA_sim.csv", row.names = FALSE)

# plots y vs t
p_tr <- ggplot() +
  geom_point(data = df_tr, aes(x = t, y = y), size = 1) +
  geom_ribbon(data = fit_tr_grid, aes(x = x0, ymin = lwr, ymax = upr), alpha = 0.25) +
  geom_line(data = fit_tr_grid, aes(x = x0, y = yhat), linewidth = 1) +
  labs(title = "Entrenamiento (Suavizado local) - Datos simulados multivariantes",
       x = "t", y = "y")

p_te <- ggplot() +
  geom_point(data = df_te, aes(x = t, y = y), size = 1) +
  geom_ribbon(data = fit_te_grid, aes(x = x0, ymin = lwr, ymax = upr), alpha = 0.25) +
  geom_line(data = fit_te_grid, aes(x = x0, y = yhat), linewidth = 1) +
  labs(title = "Prueba (Suavizado local) - Datos simulados multivariantes",
       x = "t", y = "y")

ggsave("Fig_3_4a_FDA_sim_y_t_train.png", p_tr, width = 12, height = 6, dpi = 160)
ggsave("Fig_3_4b_FDA_sim_y_t_test.png",  p_te, width = 12, height = 6, dpi = 160)

# ============== 7) superficie yhat(x1,x2) (entrenada) ==============
x1_rng <- range(df_tr$x1)
x2_rng <- range(df_tr$x2)
if (USE_QUANTILE_LIMITS) {
  x1_rng <- as.numeric(quantile(df_tr$x1, QLIM, na.rm = TRUE))
  x2_rng <- as.numeric(quantile(df_tr$x2, QLIM, na.rm = TRUE))
}

x1_seq <- seq(x1_rng[1], x1_rng[2], length.out = NGRID_SURF)
x2_seq <- seq(x2_rng[1], x2_rng[2], length.out = NGRID_SURF)

surf <- surface_predict(df_tr, x1_seq, x2_seq, span = SPAN)

# NOTA: Para evitar el warning de fill, NO ponemos fill global.
p_surf_tr <- ggplot() +
  geom_raster(data = surf, aes(x = x1, y = x2, fill = yhat), interpolate = TRUE) +
  geom_contour(data = surf, aes(x = x1, y = x2, z = yhat), linewidth = 0.2) +
  geom_point(data = df_tr, aes(x = x1, y = x2), size = 0.6) +
  labs(title = "Superficie suavizada ŷ(x1,x2) - Entrenamiento",
       x = "x1", y = "x2", fill = "yhat")

p_surf_te <- ggplot() +
  geom_raster(data = surf, aes(x = x1, y = x2, fill = yhat), interpolate = TRUE) +
  geom_contour(data = surf, aes(x = x1, y = x2, z = yhat), linewidth = 0.2) +
  geom_point(data = df_te, aes(x = x1, y = x2), size = 0.8) +
  labs(title = "Superficie suavizada ŷ(x1,x2) - Prueba (puntos) + superficie entrenada",
       x = "x1", y = "x2", fill = "yhat")

ggsave("Fig_3_4c_FDA_sim_x1x2_surface_train.png", p_surf_tr, width = 12, height = 7, dpi = 160)
ggsave("Fig_3_4d_FDA_sim_x1x2_surface_test.png",  p_surf_te, width = 12, height = 7, dpi = 160)

print(tabla)
cat("\nArchivos generados en:", getwd(), "\n")
